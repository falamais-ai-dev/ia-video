// Peças 3D do piloto (documentário 3D investigativo). Tudo em formas simples, sem modelo externo.
import React, {useMemo, useLayoutEffect, useRef} from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, staticFile} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import * as THREE from 'three';
import {Cam, FPS, W, H, FONT, YELLOW, clamp01, rnd, lerp, ease, pop, FMT} from './comum';
import ESTADOS from './estados.json';

export const OURO = '#f2b830', OURO2 = '#ffe08a', PREDIO = '#dfeaea', CHAO = '#163c45', NOITE = '#06121a', NEVOA = '#0d2f38';
export const CORES = ['#3b6fd8', '#d84b3b', '#2f9e5b', '#e0a020', '#7a4fd0', '#555', '#1c9bb0'];

// ---------- palco ----------
export const Palco = ({cam, children, bg: bg0, fog = [NEVOA, 18, 60], luz = 'noite', sombra = false, amb = {}}) => { const bg = bg0 || (fog ? fog[0] : NOITE); const A = {cidade: true, part: true, moedas: true, ...amb}; return (
  <AbsoluteFill>
    <ThreeCanvas width={FMT.w} height={FMT.h} dpr={FMT.gpu ? 1 : 0.67} gl={{antialias: FMT.gpu}} shadows={sombra}>
      <color attach="background" args={[bg]} />
      {fog && <fog attach="fog" args={fog} />}
      <Cam pos={cam.pos} look={cam.look} fov={cam.fov || 35} />
      {luz === 'noite' && <>
        <ambientLight intensity={0.55} color="#7fb6c4" />
        <directionalLight position={[-6, 10, 6]} intensity={0.9} color="#a8dbe6" castShadow={sombra} shadow-mapSize-width={1024} shadow-mapSize-height={1024} />
        <hemisphereLight args={['#2a5562', '#06121a', 0.4]} />
      </>}
      {luz === 'interior' && <>
        <ambientLight intensity={0.35} color="#ffd9a0" />
        <spotLight position={[1.5, 6, 3]} angle={0.5} penumbra={0.7} intensity={120} distance={20} color="#ffd59a" castShadow={sombra} />
      </>}
      {A.cidade && <Cidade raio={17} seed={7} cor="#9fb8bd" />}
      {A.cidade && <Janelas raio={17} seed={7} frac={0.5} />}
      {A.part && <Particulas c={cam.look} />}
      {A.moedas && <MoedasNoAr c={cam.look} />}
      {children}
    </ThreeCanvas>
  </AbsoluteFill>
); };

// poeira dourada flutuando (deixa a cena viva)
const Particulas = ({c}) => {
  const f = useCurrentFrame();
  const n = FMT.gpu ? 700 : 300;
  const it = [];
  for (let i = 0; i < n; i++) {
    const x = (rnd(i * 1.3) - 0.5) * 30, z = (rnd(i * 2.7) - 0.5) * 30;
    const y = ((rnd(i * 4.1) * 9 + f * 0.004 * (0.5 + rnd(i))) % 9);
    const s = 0.5 + rnd(i * 5.5);
    it.push({p: [x + Math.sin(f * 0.01 + i) * 0.3, y, z], s: [s, s, s]});
  }
  return <Instancias items={it} geo={<sphereGeometry args={[0.025, 6, 4]} />} cor="#ffd98a" emissive="#ffc04a" ei={2.2} />;
};
// moedas grandes girando devagar no fundo
const MoedasNoAr = ({c}) => {
  const f = useCurrentFrame();
  const it = [...Array(26)].map((_, i) => {
    return {p: [(rnd(i * 3.3) - 0.5) * 40, 3 + rnd(i * 9.2) * 8 + Math.sin(f * 0.02 + i) * 0.4, -12 - rnd(i * 7.1) * 12], r: [Math.PI / 2 + Math.sin(f * 0.01 + i), f * 0.03 + i, 0]};
  });
  return <Instancias items={it} geo={<cylinderGeometry args={[0.45, 0.45, 0.08, 24]} />} cor="#ffc93c" emissive="#b07800" ei={0.6} metalness={0.5} roughness={0.35} />;
};

export const Chao = ({c = CHAO, y = 0}) => (
  <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, y, 0]} receiveShadow><planeGeometry args={[200, 200]} /><meshStandardMaterial color={c} roughness={1} /></mesh>
);

// ---------- instâncias (muitos objetos iguais, 1 desenho) ----------
export const Instancias = ({items, geo, cor, emissive, ei = 0, roughness = 0.8, metalness = 0}) => {
  const ref = useRef();
  const m = useMemo(() => new THREE.Object3D(), []);
  useLayoutEffect(() => {
    items.forEach((it, i) => {
      m.position.set(...it.p); m.scale.set(...(it.s || [1, 1, 1])); m.rotation.set(...(it.r || [0, 0, 0]));
      m.updateMatrix(); ref.current.setMatrixAt(i, m.matrix);
      if (it.c) ref.current.setColorAt(i, new THREE.Color(it.c));
    });
    ref.current.count = items.length;
    ref.current.instanceMatrix.needsUpdate = true;
    if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true;
  });
  return (
    <instancedMesh ref={ref} args={[null, null, Math.max(1, items.length)]} frustumCulled={false}>
      {geo}
      <meshStandardMaterial color={items[0]?.c ? '#ffffff' : cor} emissive={emissive || '#000'} emissiveIntensity={ei} roughness={roughness} metalness={metalness} />
    </instancedMesh>
  );
};

// cidade de prédios brancos (corredor e centro livres)
export const useCidade = (raio = 7.5, seed = 0, livreFrente = true) => useMemo(() => {
  const out = [];
  for (let i = -12; i <= 12; i++) for (let j = -13; j <= 4; j++) {
    const x = i * 2.4 + (rnd(i * 31 + j + seed) - 0.5) * 0.6, z = j * 2.4 + (rnd(i * 7 - j + seed) - 0.5) * 0.6;
    if (Math.hypot(x, z) < raio || (livreFrente && z > 1 && Math.abs(x) < 11)) continue;
    const h = 0.8 + rnd(i * 13 + j * 5 + seed) * (2.5 + Math.min(4, Math.hypot(x, z) * 0.12));
    out.push({p: [x, h / 2, z], s: [1.3 + rnd(i + j * 3) * 0.6, h, 1.3 + rnd(i * 2 + j) * 0.6]});
  }
  return out;
}, [raio, seed, livreFrente]);
export const Cidade = ({raio, seed, livreFrente, cor = PREDIO}) => {
  const it = useCidade(raio, seed, livreFrente);
  return <Instancias items={it} geo={<boxGeometry args={[1, 1, 1]} />} cor={cor} roughness={0.85} />;
};
// janelas acesas (pontinhos) em parte dos prédios
export const Janelas = ({raio, seed, livreFrente, frac = 0.35, cor = '#ffcf70', t = 99, ritmo = 0}) => {
  const it = useCidade(raio, seed, livreFrente);
  const items = useMemo(() => {
    const o = [];
    it.forEach((b, k) => {
      if (rnd(k * 3.3 + 1) > frac) return;
      const n = 1 + Math.floor(rnd(k) * 3);
      for (let q = 0; q < n; q++) {
        const y = 0.4 + rnd(k * 5 + q) * (b.s[1] - 0.6);
        o.push({p: [b.p[0] + (rnd(k + q * 9) - 0.5) * b.s[0] * 0.7, y, b.p[2] + b.s[2] / 2 + 0.01], s: [0.22, 0.28, 0.02], k: rnd(k * 7 + q)});
      }
    });
    return o;
  }, [it, frac]);
  const vis = ritmo ? items.filter((x) => x.k * ritmo < t) : items;
  return <Instancias items={vis} geo={<boxGeometry args={[1, 1, 1]} />} cor={cor} emissive={cor} ei={1.2} />;
};

// ---------- gente ----------
export const Boneco = ({p, c = '#3b6fd8', s = 1, r = 0}) => (
  <group position={p} scale={s} rotation={[0, r, 0]}>
    <mesh position={[0, 0.2, 0]}><cylinderGeometry args={[0.08, 0.1, 0.38, 8]} /><meshStandardMaterial color={c} /></mesh>
    <mesh position={[0, 0.47, 0]}><sphereGeometry args={[0.09, 12, 8]} /><meshStandardMaterial color="#e8c4a0" /></mesh>
  </group>
);
// multidão em instâncias: corpo + cabeça
export const Multidao = ({items}) => (
  <>
    <Instancias items={items.map((b) => ({p: [b.p[0], b.p[1] + 0.2 * (b.s || 1), b.p[2]], s: [b.s || 1, b.s || 1, b.s || 1], c: b.c}))} geo={<cylinderGeometry args={[0.08, 0.1, 0.38, 6]} />} cor="#3b6fd8" />
    <Instancias items={items.map((b) => ({p: [b.p[0], b.p[1] + 0.47 * (b.s || 1), b.p[2]], s: [b.s || 1, b.s || 1, b.s || 1]}))} geo={<sphereGeometry args={[0.09, 8, 6]} />} cor="#e8c4a0" />
  </>
);

// ---------- dinheiro ----------
export const Moeda = ({p, s = 1, r = [0, 0, 0]}) => (
  <mesh position={p} scale={s} rotation={r}>
    <cylinderGeometry args={[0.2, 0.2, 0.06, 20]} />
    <meshStandardMaterial color="#ffc93c" metalness={0.4} roughness={0.45} emissive="#7a5200" emissiveIntensity={0.3} />
  </mesh>
);
const _texCache = {};
export const texMoedas = (c1 = '#ffd54f', c2 = '#a87800') => {
  const k = c1 + c2; if (_texCache[k]) return _texCache[k];
  const cv = document.createElement('canvas'); cv.width = 8; cv.height = 64; const g = cv.getContext('2d');
  g.fillStyle = c1; g.fillRect(0, 0, 8, 64); for (let y = 0; y < 64; y += 8) { g.fillStyle = c2; g.fillRect(0, y, 8, 2); }
  const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace;
  return (_texCache[k] = t);
};
export const Pilha = ({p = [0, 0, 0], h, r = 0.5, c1, c2, emis = 0.15}) => {
  const tx = useMemo(() => { const t = texMoedas(c1, c2).clone(); t.needsUpdate = true; return t; }, [c1, c2]);
  tx.repeat.set(3, Math.max(1, h * 5));
  if (h <= 0.001) return null;
  return (
    <mesh position={[p[0], p[1] + h / 2, p[2]]}>
      <cylinderGeometry args={[r, r, h, 32]} />
      <meshStandardMaterial map={tx} metalness={0.2} roughness={0.5} emissive="#5a3a00" emissiveIntensity={emis} />
    </mesh>
  );
};

// ---------- pirâmide (topo nasce primeiro; níveis novos entram por baixo) ----------
export const Piramide = ({n, NIV = 8, HN = 0.72, w0 = 1.0, dw = 1.3, gente = true, quebra = 0, cor = OURO, congela = 0}) => {
  const els = [];
  const inteiros = Math.floor(n), frac = n - inteiros;
  const total = Math.min(n, NIV);
  for (let k = 0; k < Math.ceil(n) && k < NIV; k++) {
    const s = k < inteiros ? 1 : frac;
    const base = (total - 1 - k) * HN;
    const w = w0 + k * dw;
    let y = Math.max(0, base) + HN / 2;
    // desabamento: níveis de baixo pra cima caem e se espalham
    let dx = 0, dz = 0, rot = 0;
    if (quebra > 0) {
      const q = clamp01(quebra * 1.6 - (NIV - 1 - k) * 0.08);
      y = lerp(y, HN / 2 * (0.3 + rnd(k) * 0.5), q * q);
      dx = (rnd(k * 3) - 0.5) * 3 * q; dz = (rnd(k * 5) - 0.5) * 3 * q; rot = (rnd(k * 7) - 0.5) * 0.9 * q;
    }
    els.push(
      <group key={k} position={[dx, y, dz]} rotation={[rot * 0.4, rot, rot]} scale={[1, Math.max(0.001, s), 1]}>
        <mesh>
          <boxGeometry args={[w, HN * 0.96, w]} />
          <meshStandardMaterial color={k === 0 ? OURO2 : cor} emissive={k === 0 ? '#ffb300' : '#b07800'} emissiveIntensity={k === 0 ? 1.2 : 0.45 * (1 - congela * 0.6)} metalness={0.3} roughness={0.45} />
        </mesh>
      </group>
    );
    if (gente && s > 0.9 && k + 1 < Math.ceil(n) && quebra < 0.05) {
      const cnt = 2 + k * 3;
      for (let q = 0; q < cnt; q++) {
        const side = Math.floor(rnd(q + k * 17) * 4), r = w / 2 + 0.08, off = (rnd(q * 3 + k) - 0.5) * w * 0.9;
        const pos = side === 0 ? [off, 0, r] : side === 1 ? [r, 0, off] : side === 2 ? [off, 0, -r] : [-r, 0, off];
        els.push(<Boneco key={`b${k}-${q}`} p={[pos[0], y - HN / 2, pos[2]]} c={CORES[(q + k) % CORES.length]} s={1.6} />);
      }
    }
  }
  return <group>{els}</group>;
};

// ---------- objetos ----------
export const Telefone = ({p = [0, 0, 0], s = 1, r = 0, cor = OURO, emis = 0.4}) => (
  <group position={p} scale={s} rotation={[0, r, 0]}>
    <mesh position={[0, 0.35, 0]}><boxGeometry args={[1.6, 0.7, 1.1]} /><meshStandardMaterial color={cor} emissive="#7a5200" emissiveIntensity={emis} roughness={0.45} /></mesh>
    <mesh position={[0, 0.72, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.18, 0.18, 1.7, 16]} /><meshStandardMaterial color="#222" roughness={0.5} /></mesh>
    {[-0.75, 0.75].map((x) => <mesh key={x} position={[x, 0.72, 0]}><boxGeometry args={[0.35, 0.3, 0.55]} /><meshStandardMaterial color="#222" /></mesh>)}
    {[...Array(9)].map((_, i) => <mesh key={i} position={[-0.3 + (i % 3) * 0.3, 0.71, -0.15 + Math.floor(i / 3) * 0.2]}><boxGeometry args={[0.18, 0.04, 0.12]} /><meshStandardMaterial color="#fff6dd" /></mesh>)}
  </group>
);

export const Kit = ({p, s = 1, abre = 0, cor = OURO}) => (
  <group position={p} scale={s}>
    <mesh position={[0, 0.5, 0]}><boxGeometry args={[1.2, 1, 1.2]} /><meshStandardMaterial color={cor} emissive="#7a5200" emissiveIntensity={0.4} roughness={0.45} /></mesh>
    <group position={[0, 1.0, -0.6]} rotation={[-abre * 1.9, 0, 0]}>
      <mesh position={[0, 0.06, 0.6]}><boxGeometry args={[1.28, 0.12, 1.28]} /><meshStandardMaterial color={OURO2} emissive="#ffb300" emissiveIntensity={0.3} /></mesh>
    </group>
    <mesh position={[0, 0.5, 0.61]}><boxGeometry args={[0.18, 1.0, 0.02]} /><meshStandardMaterial color="#c0392b" /></mesh>
  </group>
);

export const Pedestal = ({p, h = 0.6, w = 1.8}) => (
  <mesh position={[p[0], h / 2, p[2]]}><cylinderGeometry args={[w / 2, w / 2 + 0.1, h, 32]} /><meshStandardMaterial color="#20444d" roughness={0.6} /></mesh>
);

export const Forum = ({p = [0, 0, 0], s = 1, janela = 1}) => (
  <group position={p} scale={s}>
    <mesh position={[0, 0.15, 0]}><boxGeometry args={[4.4, 0.3, 3.2]} /><meshStandardMaterial color="#c9d6d8" /></mesh>
    <mesh position={[0, 1.3, -0.3]}><boxGeometry args={[3.8, 2.0, 2.2]} /><meshStandardMaterial color="#e6eeee" /></mesh>
    {[...Array(6)].map((_, i) => <mesh key={i} position={[-1.6 + i * 0.64, 1.3, 0.95]}><cylinderGeometry args={[0.12, 0.12, 2.0, 12]} /><meshStandardMaterial color="#f4f7f7" /></mesh>)}
    <mesh position={[0, 2.5, 0.2]}><boxGeometry args={[4.1, 0.25, 2.9]} /><meshStandardMaterial color="#d7e2e3" /></mesh>
    <mesh position={[0, 2.9, -0.95]}><primitive object={FRONTAO} attach="geometry" /><meshStandardMaterial color="#d7e2e3" /></mesh>
    <mesh position={[0.9, 1.5, 0.82]}><boxGeometry args={[0.5, 0.7, 0.02]} /><meshStandardMaterial color="#ffcf70" emissive="#ffb84a" emissiveIntensity={1.5 * janela} /></mesh>
  </group>
);
const _f = new THREE.Shape(); _f.moveTo(-2.05, 0); _f.lineTo(2.05, 0); _f.lineTo(0, 0.8); _f.lineTo(-2.05, 0);
const FRONTAO = new THREE.ExtrudeGeometry(_f, {depth: 2.3, bevelEnabled: false});

export const Martelo = ({p = [0, 0, 0], ang = 0, s = 1}) => (
  <group position={p} scale={s} rotation={[0, 0, ang]}>
    <mesh position={[0.9, 0, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.07, 0.08, 1.8, 12]} /><meshStandardMaterial color="#6d3f1f" roughness={0.5} /></mesh>
    <mesh position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.28, 0.28, 0.9, 20]} /><meshStandardMaterial color="#7a4623" roughness={0.45} /></mesh>
    {[-0.45, 0.45].map((z) => <mesh key={z} position={[0, 0, z]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.3, 0.3, 0.08, 20]} /><meshStandardMaterial color={OURO} metalness={0.4} roughness={0.4} /></mesh>)}
  </group>
);

export const Casa = ({p, c = '#d8e3e3', luz = 0, r = 0}) => (
  <group position={p} rotation={[0, r, 0]}>
    <mesh position={[0, 0.45, 0]}><boxGeometry args={[1, 0.9, 1]} /><meshStandardMaterial color={c} /></mesh>
    <mesh position={[0, 1.1, 0]} rotation={[0, Math.PI / 4, 0]}><coneGeometry args={[0.85, 0.5, 4]} /><meshStandardMaterial color="#9a5b4a" /></mesh>
    <mesh position={[0.2, 0.5, 0.51]}><boxGeometry args={[0.3, 0.3, 0.02]} /><meshStandardMaterial color={luz ? '#ffd27a' : '#2b3d44'} emissive={luz ? '#ffb300' : '#000'} emissiveIntensity={luz * 2} /></mesh>
  </group>
);

export const Aviao = ({p, r = 0, s = 1}) => (
  <group position={p} rotation={[0, r, 0]} scale={s}>
    <mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.12, 0.08, 1.4, 12]} /><meshStandardMaterial color="#eef3f3" /></mesh>
    <mesh position={[0.05, 0, 0]}><boxGeometry args={[0.35, 0.04, 1.4]} /><meshStandardMaterial color="#d5dede" /></mesh>
    <mesh position={[-0.6, 0.15, 0]}><boxGeometry args={[0.2, 0.3, 0.04]} /><meshStandardMaterial color="#d5dede" /></mesh>
  </group>
);

// celular com balão vermelho (ameaça), sem letras
export const Celular = ({p, s = 1, balao = 1, r = 0}) => (
  <group position={p} scale={s} rotation={[0, r, 0]}>
    <mesh><boxGeometry args={[0.5, 0.9, 0.06]} /><meshStandardMaterial color="#111" /></mesh>
    <mesh position={[0, 0, 0.035]}><boxGeometry args={[0.44, 0.8, 0.01]} /><meshStandardMaterial color="#1f2a33" emissive="#2a3a48" emissiveIntensity={0.8} /></mesh>
    <group position={[0, 0.12, 0.05]} scale={balao}>
      <mesh><boxGeometry args={[0.36, 0.2, 0.02]} /><meshStandardMaterial color="#e53935" emissive="#e53935" emissiveIntensity={1.2} /></mesh>
      {[-0.1, 0, 0.1].map((x) => <mesh key={x} position={[x, 0, 0.012]}><boxGeometry args={[0.05, 0.05, 0.01]} /><meshStandardMaterial color="#fff" emissive="#fff" emissiveIntensity={0.6} /></mesh>)}
    </group>
  </group>
);

// ---------- mapa do Brasil em relevo ----------
const ESC_MAPA = 0.42, CX = -52, CY = -14;
export const geoXZ = (lon, lat) => [(lon - CX) * ESC_MAPA, -(lat - CY) * ESC_MAPA * -1 * -1];
const shapesDe = (nome) => (ESTADOS[nome] || []).map((ring) => {
  const s = new THREE.Shape();
  ring.forEach(([lon, lat], i) => { const x = (lon - CX) * ESC_MAPA, y = (lat - CY) * ESC_MAPA; i ? s.lineTo(x, y) : s.moveTo(x, y); });
  return s;
});
const _geoCache = {};
const geoEstado = (nome, alt) => {
  const k = nome + alt; if (_geoCache[k]) return _geoCache[k];
  return (_geoCache[k] = new THREE.ExtrudeGeometry(shapesDe(nome), {depth: alt, bevelEnabled: false}));
};
export const NOMES_ESTADOS = Object.keys(ESTADOS);
// estado: {nome: {cor, alt, sobe, emis}}
export const MapaBrasil = ({destaque = {}, base = '#2c6170', alt = 0.25, p = [0, 0, 0], s = 1}) => (
  <group position={p} scale={s} rotation={[-Math.PI / 2, 0, 0]}>
    {NOMES_ESTADOS.map((n) => {
      const d = destaque[n] || {};
      return (
        <mesh key={n} geometry={geoEstado(n, d.alt || alt)} position={[0, 0, d.sobe || 0]}>
          <meshStandardMaterial color={d.cor || base} emissive={d.cor || '#000'} emissiveIntensity={d.emis || 0} roughness={0.7} />
        </mesh>
      );
    })}
  </group>
);
// lon/lat -> posição no mapa (plano XZ, mapa deitado)
export const ll = (lon, lat, y = 0.3) => [(lon - CX) * ESC_MAPA, y, -(lat - CY) * ESC_MAPA];
// pontos aleatórios dentro de um estado
const dentro = (pt, ring) => { let c = false; for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) { const [xi, yi] = ring[i], [xj, yj] = ring[j]; if ((yi > pt[1]) !== (yj > pt[1]) && pt[0] < ((xj - xi) * (pt[1] - yi)) / (yj - yi) + xi) c = !c; } return c; };
export const pontosNoBrasil = (n, seed = 1) => {
  const out = []; let k = 0;
  const rings = NOMES_ESTADOS.flatMap((nm) => ESTADOS[nm].map((r) => ({nm, r})));
  while (out.length < n && k < n * 40) {
    k++;
    const lon = -74 + rnd(k * 1.37 + seed) * 40, lat = -34 + rnd(k * 2.71 + seed * 3) * 39;
    const hit = rings.find((x) => dentro([lon, lat], x.r));
    if (hit) out.push({lon, lat, nm: hit.nm});
  }
  return out;
};

// ---------- globo ----------
export const Globo = ({r = 3, rotY = 0, p = [0, 0, 0], tex}) => (
  <mesh position={p} rotation={[0.25, rotY, 0]}>
    <sphereGeometry args={[r, 64, 48]} />
    <meshStandardMaterial map={tex} roughness={0.8} emissive="#0c2a33" emissiveIntensity={0.3} />
  </mesh>
);
export const sph = (lon, lat, r) => {
  const la = (lat * Math.PI) / 180, lo = (lon * Math.PI) / 180;
  return [r * Math.cos(la) * Math.sin(lo + Math.PI / 2) * -1 * -1, r * Math.sin(la), r * Math.cos(la) * Math.cos(lo + Math.PI / 2)];
};

// ---------- HTML por cima ----------
export const CartaoCapitulo = ({n, titulo, frame, dur}) => {
  const o = interpolate(frame, [0, 10, dur - 10, dur], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const dx = interpolate(frame, [0, dur], [-16, 16]);
  return (
    <AbsoluteFill style={{background: NOITE, alignItems: 'center', justifyContent: 'center'}}>
      <div style={{opacity: o, transform: `translateX(${dx}px)`, textAlign: 'center', fontFamily: FONT, color: 'white'}}>
        <div style={{fontSize: 30, fontWeight: 700, letterSpacing: 12, color: '#9fd3e0'}}>CAPÍTULO {n}</div>
        <div style={{fontSize: 104, fontWeight: 900, letterSpacing: 3, marginTop: 6}}>{titulo}</div>
        <div style={{width: 160, height: 5, background: YELLOW, margin: '18px auto 0'}} />
      </div>
    </AbsoluteFill>
  );
};

export const Numero = ({x, y, txt, sub, delay = 0, size = 150, cor = YELLOW, ancora = 'center'}) => {
  const frame = useCurrentFrame();
  if (frame < delay) return null;
  const p = pop(frame, delay);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(${ancora === 'center' ? '-50%' : '0'},-50%) scale(${0.85 + 0.15 * p})`, opacity: clamp01(p * 1.5), textAlign: ancora === 'center' ? 'center' : 'left', fontFamily: FONT}}>
      <div style={{fontWeight: 900, fontSize: size, color: cor, lineHeight: 1, textShadow: '0 6px 30px rgba(0,0,0,0.7)', WebkitTextStroke: '3px rgba(0,0,0,0.35)'}}>{txt}</div>
      {sub && <div style={{fontWeight: 700, fontSize: size * 0.24, color: 'white', letterSpacing: 4, marginTop: 10, textShadow: '0 2px 12px rgba(0,0,0,0.9)'}}>{sub}</div>}
    </div>
  );
};

export const Fonte = ({txt}) => (
  <div style={{position: 'absolute', left: 48, bottom: 92, fontFamily: FONT, fontWeight: 600, fontSize: 22, color: 'rgba(255,255,255,0.75)', textShadow: '0 1px 6px rgba(0,0,0,0.9)'}}>{txt}</div>
);

export const Faixas = () => (
  <>
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: 60, background: 'black'}} />
    <div style={{position: 'absolute', left: 0, bottom: 0, width: W, height: 60, background: 'black'}} />
  </>
);

// documento em papel (texto em código)
export const Documento = ({x, y, w = 760, rot = -2, entra = 1, children}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, transform: `translateY(${(1 - entra) * 700}px) rotate(${rot}deg)`, background: '#e0d5bb', color: '#2b2b2b',
    padding: '34px 42px', boxShadow: '0 20px 50px rgba(0,0,0,0.6)', fontFamily: 'Liberation Serif, serif', fontSize: 30, lineHeight: 1.4}}>{children}</div>
);
export const Marca = ({p, children}) => (
  <span style={{backgroundImage: 'linear-gradient(rgba(255,214,0,0.85), rgba(255,214,0,0.85))', backgroundRepeat: 'no-repeat', backgroundSize: `${p * 100}% 80%`, backgroundPosition: '0 70%'}}>{children}</span>
);
