// Cenas do capítulo 6, do fecho, título e cartões.
import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import * as THREE from 'three';
import {FPS, W, H, FONT, YELLOW, clamp01, rnd, lerp, ease} from './comum';
import {Palco, Chao, Forum, Piramide, Telefone, Martelo, Boneco, Moeda, Multidao, OURO, OURO2, NOITE, CORES} from './kit';
import {sp, rampa, camK, VERM} from './base';

// ---------- linha do tempo da Justiça brasileira ----------
// marcos: [{x, t, tipo}]
const Mini = ({tipo, s}) => {
  if (tipo === 'piramide') return <group scale={0.35 * s}><Piramide n={5} gente={false} /></group>;
  if (tipo === 'forum') return <Forum p={[0, 0, 0]} s={0.55 * s} />;
  if (tipo === 'grade') return (
    <group scale={s}>
      <Boneco p={[0, 0, -0.3]} c="#5b6770" s={1.8} />
      {[...Array(7)].map((_, i) => <mesh key={i} position={[-0.9 + i * 0.3, 0.8, 0.3]}><cylinderGeometry args={[0.03, 0.03, 1.6, 6]} /><meshStandardMaterial color="#9aa7ad" metalness={0.8} roughness={0.3} /></mesh>)}
    </group>
  );
  if (tipo === 'martelo') return <group scale={s} position={[0, 0.5, 0]} rotation={[0, 0.5, 0]}><Martelo s={0.8} /></group>;
  if (tipo === 'jornal') return (
    <group scale={s} position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0.2]}>
      <mesh><boxGeometry args={[1.6, 2.1, 0.03]} /><meshStandardMaterial color="#d8d2c0" /></mesh>
      {[...Array(7)].map((_, i) => <mesh key={i} position={[0, 0.75 - i * 0.22, 0.02]}><boxGeometry args={[i === 0 ? 1.3 : 1.2, i === 0 ? 0.16 : 0.06, 0.01]} /><meshStandardMaterial color="#333" /></mesh>)}
    </group>
  );
  return null;
};
export const SLinha = ({t, keys, marcos, fimLinha, children}) => {
  const cam = camK(keys, t);
  const L = lerp(0, fimLinha.x, rampa(t, fimLinha.t0, fimLinha.t1));
  return (
    <Palco cam={cam} fog={['#0d2f38', 10, 40]} amb={{cidade: false}}>
      <Chao />
      <mesh position={[L / 2 - 2, 0.02, 0]}><boxGeometry args={[L + 4, 0.04, 0.12]} /><meshStandardMaterial color="#ffd54f" emissive="#ffb300" emissiveIntensity={1.2} /></mesh>
      {marcos.map((m, i) => {
        const s = sp(t, m.t);
        if (s < 0.01) return null;
        return (
          <group key={i} position={[m.x, 0, 0]}>
            <mesh position={[0, 0.2, 0]}><cylinderGeometry args={[1.5, 1.6, 0.4, 32]} /><meshStandardMaterial color="#20444d" /></mesh>
            <pointLight position={[0, 4, 2.5]} intensity={45} distance={12} color="#ffd890" />
            <group position={[0, 0.4, 0]}><Mini tipo={m.tipo} s={s} /></group>
          </group>
        );
      })}
      <pointLight position={[cam.look[0], 5, 4]} intensity={60} distance={18} color="#ffd890" />
      {children}
    </Palco>
  );
};

// ---------- fecho: pirâmides de outras épocas ----------
const Icone = ({tipo}) => {
  const m = <meshStandardMaterial color={OURO2} emissive="#ffb300" emissiveIntensity={0.6} />;
  if (tipo === 'boi') return (
    <group scale={0.9}>
      <mesh position={[0, 0.6, 0]}><boxGeometry args={[1.2, 0.55, 0.55]} />{m}</mesh>
      <mesh position={[0.75, 0.75, 0]}><boxGeometry args={[0.38, 0.36, 0.36]} />{m}</mesh>
      {[[-0.45, -0.18], [-0.45, 0.18], [0.45, -0.18], [0.45, 0.18]].map(([x, z], i) => <mesh key={i} position={[x, 0.17, z]}><boxGeometry args={[0.12, 0.34, 0.12]} />{m}</mesh>)}
      {[-0.14, 0.14].map((z) => <mesh key={z} position={[0.8, 1.0, z]} rotation={[z * 4, 0, 0]}><coneGeometry args={[0.05, 0.25, 6]} />{m}</mesh>)}
    </group>
  );
  if (tipo === 'avestruz') return (
    <group scale={0.9}>
      <mesh position={[0, 0.8, 0]} scale={[1.2, 0.8, 0.8]}><sphereGeometry args={[0.35, 16, 12]} />{m}</mesh>
      <mesh position={[0.35, 1.25, 0]} rotation={[0, 0, -0.3]}><cylinderGeometry args={[0.05, 0.07, 0.8, 8]} />{m}</mesh>
      <mesh position={[0.48, 1.65, 0]}><sphereGeometry args={[0.1, 10, 8]} />{m}</mesh>
      {[-0.1, 0.1].map((z) => <mesh key={z} position={[0, 0.25, z]}><cylinderGeometry args={[0.03, 0.03, 0.55, 6]} />{m}</mesh>)}
    </group>
  );
  if (tipo === 'telefone') return <Telefone p={[0, 0, 0]} s={0.55} cor={OURO2} emis={0.6} />;
  return (
    <group position={[0, 0.6, 0]} rotation={[Math.PI / 2, 0, 0]}>
      <mesh><cylinderGeometry args={[0.55, 0.55, 0.1, 32]} />{m}</mesh>
      <mesh position={[0, -0.06, 0]}><torusGeometry args={[0.38, 0.04, 6, 6]} /><meshStandardMaterial color="#7a5200" /></mesh>
    </group>
  );
};
export const SFecho = ({t, keys, acende, une, children}) => {
  const cam = camK(keys, t);
  const TIPOS = ['boi', 'avestruz', 'telefone', 'cripto'];
  const u = rampa(t, une, une + 1.2);
  return (
    <Palco cam={cam} fog={['#0d2f38', 12, 45]}>
      <Chao />
      {TIPOS.map((tp, i) => {
        const x = (i - 1.5) * 6.5;
        const a = sp(t, acende[i]);
        return (
          <group key={tp} position={[x, 0, 0]}>
            <Piramide n={5} gente={false} w0={0.8} dw={1.0} HN={0.6} cor={new THREE.Color('#3a5560').lerp(new THREE.Color(u > 0 ? '#d84b3b' : OURO), Math.max(a, u)).getStyle()} />
            <group position={[0, 5 * 0.6, 0]} scale={0.4 + 0.6 * a}><Icone tipo={tp} /></group>
            <pointLight position={[0, 5, 3]} intensity={60 * Math.max(a, u)} distance={14} color={u > 0.5 ? '#ff6a50' : '#ffd890'} />
          </group>
        );
      })}
      {children}
    </Palco>
  );
};

// ---------- título do vídeo ----------
export const Titulo = ({lt, dur}) => {
  const o = interpolate(lt, [0, 0.15, dur - 0.5, dur], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const z = lerp(1.08, 1.0, ease(clamp01(lt / 0.6)));
  const ls = lerp(30, 6, ease(clamp01(lt / 1.5)));
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', opacity: o}}>
      <div style={{transform: `scale(${z})`, textAlign: 'center', fontFamily: FONT, color: 'white'}}>
        <div style={{fontSize: 40, fontWeight: 700, letterSpacing: ls, color: '#9fd3e0'}}>A HISTÓRIA SECRETA DO</div>
        <div style={{fontSize: 128, fontWeight: 900, letterSpacing: 2, lineHeight: 1.0, marginTop: 10, textShadow: '0 10px 50px rgba(0,0,0,0.9)'}}>MAIOR GOLPE</div>
        <div style={{fontSize: 128, fontWeight: 900, letterSpacing: 2, lineHeight: 1.0, color: YELLOW, textShadow: '0 10px 50px rgba(0,0,0,0.9)'}}>FINANCEIRO</div>
        <div style={{fontSize: 52, fontWeight: 800, letterSpacing: ls * 0.6, marginTop: 12}}>DO BRASIL</div>
      </div>
    </AbsoluteFill>
  );
};

// ---------- cartão de capítulo ----------
export const Cartao = ({n, titulo, lt, dur}) => {
  const o = interpolate(lt, [0, 0.25, dur - 0.3, dur], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const dx = lerp(-18, 18, lt / dur);
  const lin = ease(clamp01((lt - 0.2) / 0.6));
  return (
    <AbsoluteFill style={{background: `radial-gradient(ellipse at ${50 + dx}% 50%, #0f3440 0%, ${NOITE} 65%)`, alignItems: 'center', justifyContent: 'center'}}>
      <div style={{opacity: o, transform: `translateX(${dx}px)`, textAlign: 'center', fontFamily: FONT, color: 'white'}}>
        <div style={{fontSize: 32, fontWeight: 700, letterSpacing: 14, color: '#9fd3e0'}}>CAPÍTULO {n}</div>
        <div style={{fontSize: 108, fontWeight: 900, letterSpacing: 3, marginTop: 8, textShadow: '0 8px 40px rgba(0,0,0,0.8)'}}>{titulo}</div>
        <div style={{width: 200 * lin, height: 6, background: YELLOW, margin: '20px auto 0'}} />
      </div>
    </AbsoluteFill>
  );
};
