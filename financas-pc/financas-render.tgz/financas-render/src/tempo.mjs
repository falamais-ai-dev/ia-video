// Linha do tempo do piloto (segundos). Usado pelo Remotion e pelo script de áudio.
export const FPS = 30;
export const DUR = [31.28, 70.08, 45.2, 73.96, 61.92, 55.68, 38.48, 25.36]; // narração de cada bloco
export const CAPS = [null, 'A PROMESSA', 'A FEBRE', 'A CONTA QUE NÃO FECHA', 'A JUÍZA', 'DO OUTRO LADO DO MUNDO', 'E NO BRASIL?', null];
export const CARD = 2.6, TITULO = 3.8;

const L = [];
let t = 0.6;
for (let i = 0; i < 8; i++) {
  const b = {i, card: null, ini: 0, fim: 0};
  if (i === 0) { b.ini = t; }
  else if (CAPS[i]) { b.card = t; b.ini = t + CARD; }
  else { b.ini = t + 1.2; }
  b.fim = b.ini + DUR[i];
  L.push(b);
  t = b.fim + (i === 0 ? 0.2 : 0.4);
  if (i === 0) { b.titulo = t; t += TITULO; }
}
export const BLOCOS = L;
export const TOTAL = L[7].fim + 4.2;
export const TOTAL_F = Math.round(TOTAL * FPS);

// efeitos: [bloco, tempo dentro da narração do bloco, tipo, ganho]
export const SFX = [
  [0, -0.4, 'drone', 1], [0, 3.3, 'whoosh', 0.6], [0, 6.75, 'carimbo', 1], [0, 8.1, 'whoosh', 0.5],
  ...[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((k) => [0, 9.5 + k * 0.17, 'blip', 0.5]),
  [0, 11.6, 'whoosh', 0.5], [0, 17.4, 'whoosh', 0.5], [0, 21.0, 'desce', 0.8], [0, 22.3, 'whoosh', 0.6], [0, 24.1, 'thud', 0.8],
  [0, 25.5, 'riser', 0.8], [0, 31.5, 'boom', 1.2],
  // capítulo 1
  [1, 0.1, 'whoosh', 0.5], [1, 3.4, 'blip', 0.8], [1, 4.4, 'whoosh', 0.5], [1, 7.9, 'whoosh', 0.5], [1, 13.1, 'whoosh', 0.5],
  [1, 16.7, 'thud', 0.8], [1, 18.0, 'whoosh', 0.5], [1, 21.0, 'moeda', 0.8], [1, 23.7, 'thud', 0.9], [1, 25.5, 'whoosh', 0.5],
  [1, 31.3, 'clique', 0.7], [1, 31.8, 'clique', 0.7], [1, 32.5, 'blip', 0.7],
  ...[0, 1, 2, 3, 4, 5, 6].map((k) => [1, 33.4 + k * 0.2, 'blip', 0.45]), [1, 36.2, 'moeda', 1],
  [1, 38.0, 'whoosh', 0.5], ...[...Array(26)].map((_, k) => [1, 39.2 + k * 0.155, 'moeda', 0.35]), [1, 41.8, 'thud', 0.8],
  [1, 43.6, 'whoosh', 0.5], [1, 45.8, 'riser', 0.5], [1, 46.5, 'thud', 0.7], [1, 46.9, 'whoosh', 0.5], [1, 49.9, 'blip', 0.6], [1, 52.5, 'boom', 0.8],
  [1, 53.9, 'whoosh', 0.5], [1, 60.8, 'moeda', 0.8], [1, 61.5, 'desce', 0.6], [1, 65.4, 'whoosh', 0.5], [1, 67.6, 'riser', 0.9],
  // capítulo 2
  [2, 1.4, 'thud', 0.7], [2, 4.7, 'blip', 0.6], [2, 5.8, 'whoosh', 0.5], [2, 13.2, 'thud', 0.9], [2, 15.1, 'whoosh', 0.5],
  [2, 17.2, 'boom', 0.8], [2, 22.6, 'thud', 0.7], [2, 25.8, 'blip', 0.8], [2, 27.2, 'whoosh', 0.5], [2, 29.8, 'clique', 0.9],
  [2, 34.0, 'whoosh', 0.5], ...[0, 1, 2, 3, 4, 5, 6, 7].map((k) => [2, 35.7 + k * 0.28, 'moeda', 0.5]), [2, 39.8, 'whoosh', 0.5], [2, 42.6, 'riser', 0.8],
  // capítulo 3
  [3, 0.0, 'drone', 0.8], [3, 11.4, 'boom', 0.9], [3, 13.7, 'whoosh', 0.5], [3, 19.4, 'moeda', 0.9], [3, 21.4, 'thud', 1],
  [3, 27.1, 'moeda', 0.9], [3, 29.2, 'whoosh', 0.5], [3, 32.2, 'desce', 0.7], [3, 35.9, 'boom', 1.1], [3, 43.8, 'whoosh', 0.5],
  [3, 47.6, 'blip', 0.6], [3, 49.1, 'blip', 0.7], [3, 50.8, 'blip', 0.8], [3, 52.9, 'blip', 0.9], [3, 54.2, 'riser', 0.7], [3, 57.0, 'boom', 1],
  [3, 60.0, 'thud', 0.8], [3, 62.4, 'whoosh', 0.5], [3, 65.0, 'queda', 1.2], [3, 66.6, 'whoosh', 0.4], [3, 73.0, 'riser', 0.6],
  // capítulo 4
  [4, 0.0, 'whoosh', 0.5], [4, 2.7, 'papel', 1], [4, 4.1, 'marcador', 0.8], [4, 7.7, 'whoosh', 0.5], [4, 11.1, 'martelo', 1.2],
  [4, 13.4, 'whoosh', 0.5], [4, 15.4, 'carimbo', 0.9], [4, 16.7, 'whoosh', 0.4], [4, 19.2, 'desce', 0.8], [4, 20.5, 'whoosh', 0.5],
  ...[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((k) => [4, 26.4 + k * 0.2, 'blip', 0.5]), [4, 28.3, 'thud', 0.7], [4, 32.7, 'boom', 0.8], [4, 35.3, 'whoosh', 0.5],
  [4, 38.3, 'moeda', 0.6], [4, 40.1, 'thud', 0.6], [4, 42.0, 'blip', 0.5], [4, 42.6, 'blip', 0.5], [4, 43.6, 'blip', 0.5], [4, 46.0, 'desce', 0.9],
  [4, 49.7, 'whoosh', 0.5], [4, 57.6, 'freio', 1], [4, 58.7, 'thud', 0.8], [4, 59.5, 'whoosh', 0.6],
  // capítulo 5
  [5, 3.6, 'blip', 0.5], [5, 6.7, 'papel', 0.9], [5, 11.8, 'carimbo', 1], [5, 14.7, 'carimbo', 1], [5, 16.0, 'whoosh', 0.5], [5, 18.6, 'aviao', 0.8],
  [5, 24.0, 'whoosh', 0.5], [5, 29.1, 'carimbo', 0.9], [5, 31.6, 'grade', 1], [5, 33.0, 'whoosh', 0.5], [5, 36.6, 'thud', 0.8], [5, 40.6, 'boom', 0.9],
  [5, 43.4, 'whoosh', 0.5], [5, 47.2, 'moeda', 0.9], [5, 51.2, 'whoosh', 0.5], [5, 53.5, 'thud', 0.8],
  // capítulo 6
  [6, 2.7, 'thud', 0.7], [6, 4.2, 'carimbo', 1], [6, 8.7, 'thud', 0.6], [6, 11.8, 'thud', 0.6], [6, 12.9, 'carimbo', 0.9],
  [6, 16.7, 'grade', 1], [6, 21.3, 'grade', 0.8], [6, 22.9, 'thud', 0.6], [6, 26.3, 'martelo', 1], [6, 30.1, 'thud', 0.6], [6, 33.7, 'desce', 0.8],
  // fecho
  [7, 3.3, 'blip', 0.6], [7, 4.1, 'blip', 0.6], [7, 5.3, 'blip', 0.6], [7, 6.5, 'blip', 0.6], [7, 8.4, 'boom', 0.8],
  [7, 10.1, 'carimbo', 0.9], [7, 13.6, 'carimbo', 0.9], [7, 16.6, 'carimbo', 0.9], [7, 18.6, 'riser', 0.7], [7, 20.2, 'boom', 1], [7, 21.5, 'blip', 0.6],
];
