// Cenas reutilizáveis (parte B). Todos os tempos são do bloco de narração (t).
import React, {useMemo} from 'react';
import {AbsoluteFill} from 'remotion';
import * as THREE from 'three';
import {FPS, W, H, FONT, YELLOW, clamp01, rnd, lerp, ease, FMT} from './comum';
import {Palco, Chao, Cidade, Forum, Multidao, Instancias, Piramide, Telefone, Pedestal, Kit, Boneco, Martelo, Pilha, OURO, OURO2, CORES} from './kit';
import {sp, rampa, camK, VERM} from './base';

// ---------- pilhas de moedas ----------
// pilhas: [{x, z, h, r, c1, c2}]
export const SPilhas = ({t, keys, pilhas, fog = ['#0d2f38', 14, 60], torre, children}) => {
  const cam = camK(keys, t);
  return (
    <Palco cam={cam} fog={fog}>
      <Chao />
      <spotLight position={[0, 20, 8]} angle={0.6} penumbra={0.7} intensity={500} distance={70} color="#ffd890" />
      {pilhas.map((P, i) => <Pilha key={i} p={[P.x, 0, P.z || 0]} h={P.h} r={P.r || 0.5} c1={P.c1} c2={P.c2} emis={P.emis || 0.2} />)}
      {torre && torre.h > 0.01 && (
        <group position={[torre.x, torre.h / 2, 0]}>
          <mesh><boxGeometry args={[torre.w, torre.h, torre.w]} /><meshStandardMaterial color="#ffd54f" transparent opacity={0.08} /></mesh>
          <lineSegments><edgesGeometry args={[new THREE.BoxGeometry(torre.w, torre.h, torre.w)]} /><lineBasicMaterial color="#ffd54f" /></lineSegments>
          {[...Array(Math.floor(torre.h / 1.5))].map((_, i) => (
            <lineSegments key={i} position={[0, -torre.h / 2 + (i + 1) * 1.5, 0]}><edgesGeometry args={[new THREE.PlaneGeometry(torre.w, torre.w).rotateX(Math.PI / 2)]} /><lineBasicMaterial color="#b88a1a" /></lineSegments>
          ))}
        </group>
      )}
      {children}
    </Palco>
  );
};

// ---------- catraca de entrada ----------
export const SCatraca = ({t, keys, gira, children}) => {
  const cam = camK(keys, t);
  const g = rampa(t, gira, gira + 0.8) * (Math.PI * 2 / 3);
  const andar = clamp01((t - (gira - 2.5)) / 3.5);
  return (
    <Palco cam={cam} fog={['#0b1d24', 8, 35]}>
      <Chao c="#10262d" />
      <spotLight position={[0, 8, 3]} angle={0.45} penumbra={0.6} intensity={260} distance={30} color="#ffd890" />
      {[-0.9, 0.9].map((x) => <mesh key={x} position={[x, 0.55, 0]}><boxGeometry args={[0.25, 1.1, 1.4]} /><meshStandardMaterial color="#b0bec5" metalness={0.6} roughness={0.35} /></mesh>)}
      <group position={[-0.65, 0.95, 0]} rotation={[g, 0, 0]}>
        {[0, 1, 2].map((k) => <group key={k} rotation={[k * 2.094, 0, 0]}><mesh position={[0.55, 0.3, 0]}><boxGeometry args={[1.1, 0.06, 0.06]} /><meshStandardMaterial color={OURO} emissive="#7a5200" emissiveIntensity={0.5} metalness={0.5} /></mesh></group>)}
      </group>
      <Boneco p={[0, 0, lerp(3.2, 0.9, andar)]} c="#3b6fd8" s={2.1} r={Math.PI} />
      {children}
    </Palco>
  );
};

// ---------- dois kits em pedestais ----------
export const SKits = ({t, keys, a, b, children}) => {
  const cam = camK(keys, t);
  const pa = sp(t, a), pb = sp(t, b);
  return (
    <Palco cam={cam} fog={['#0b1d24', 10, 40]}>
      <Chao c="#10262d" />
      <Pedestal p={[-2.2, 0, 0]} h={0.6} w={2} />
      <Pedestal p={[2.4, 0, 0]} h={0.6} w={2.8} />
      <pointLight position={[-2.2, 3.2, 2.2]} intensity={40 * pa} distance={9} color="#ffd890" />
      <pointLight position={[2.4, 4, 2.6]} intensity={60 * pb} distance={10} color="#ffd890" />
      {pa > 0.01 && <Kit p={[-2.2, 0.6, 0]} s={0.75 * pa} abre={rampa(t, a + 0.6, a + 1.4)} />}
      {pb > 0.01 && <Kit p={[2.4, 0.6, 0]} s={1.35 * pb} abre={rampa(t, b + 0.6, b + 1.4)} />}
      {children}
    </Palco>
  );
};

// ---------- tela do site de anúncios (HTML) ----------
export const STela = ({t, t0, copia, cola, dias, paga}) => {
  const z = lerp(1.0, 1.12, clamp01((t - t0) / 12));
  const tA = (i) => (i === 0 ? t0 + 2.8 : cola + 0.4 + i * 0.35);
  const ads = [...Array(9)].map((_, i) => ({on: t > tA(i), i}));
  const d7 = [...Array(7)].map((_, i) => t > dias + i * 0.2);
  const ROT = ['SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB', 'DOM'];
  return (
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, #12313b 0%, #06121a 70%)', overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: FMT.w / 2, top: FMT.h / 2 - 20, width: 1400, height: 800, transform: `translate(-50%,-50%) scale(${z * (FMT.v ? 0.72 : 1)})`, background: '#0e1a20', borderRadius: 26, padding: 24, boxShadow: '0 0 80px rgba(80,200,255,0.18)'}}>
        <div style={{width: '100%', height: '100%', background: '#93a3a0', borderRadius: 10, overflow: 'hidden', position: 'relative', fontFamily: FONT}}>
          <div style={{height: 70, background: '#2e5560', display: 'flex', alignItems: 'center', padding: '0 30px', gap: 20}}>
            <div style={{width: 200, height: 22, background: '#9fd3e0', borderRadius: 6}} />
            <div style={{flex: 1, height: 34, background: '#b9c6c6', borderRadius: 17}} />
          </div>
          <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 22, padding: 30}}>
            {ads.map((A) => (
              <div key={A.i} style={{height: 170, background: A.on ? '#d9cca9' : 'rgba(0,0,0,0.08)', borderRadius: 10, border: A.on ? `4px solid ${OURO}` : '4px dashed rgba(0,0,0,0.12)', transform: `scale(${A.on ? 0.9 + 0.1 * sp(t, tA(A.i)) : 1})`, padding: 16}}>
                {A.on && <>
                  <div style={{width: 60, height: 60, background: OURO, borderRadius: 30}} />
                  <div style={{height: 14, width: '80%', background: '#555', opacity: 0.4, marginTop: 14, borderRadius: 4}} />
                  <div style={{height: 14, width: '60%', background: '#555', opacity: 0.3, marginTop: 10, borderRadius: 4}} />
                </>}
              </div>
            ))}
          </div>
          {t > copia && t < cola + 0.6 && (
            <div style={{position: 'absolute', left: 520, top: 300, background: '#1e2a30', color: 'white', fontWeight: 900, fontSize: 40, padding: '14px 30px', borderRadius: 12, transform: `scale(${sp(t, copia)})`}}>{t < cola ? 'CTRL + C' : 'CTRL + V'}</div>
          )}
        </div>
      </div>
      {t > dias - 0.2 && (
        <div style={{position: 'absolute', left: FMT.w / 2, top: FMT.v ? 1260 : 930, transform: `translate(-50%,-50%) scale(${FMT.v ? 0.8 : 1})`, display: 'flex', gap: 14}}>
          {d7.map((on, i) => (
            <div key={i} style={{width: 120, height: 92, borderRadius: 12, background: on ? '#2f9e5b' : 'rgba(6,18,26,0.9)', border: '3px solid rgba(255,255,255,0.25)', color: 'white', fontFamily: FONT, fontWeight: 900, fontSize: 26, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
              {ROT[i]}<div style={{fontSize: 34}}>{on ? '✓' : ''}</div>
            </div>
          ))}
        </div>
      )}
      {t > paga && (
        <div style={{position: 'absolute', left: FMT.w / 2, top: FMT.h / 2 - 40, transform: `translate(-50%,-50%) scale(${(0.6 + 0.4 * sp(t, paga)) * (FMT.v ? 0.75 : 1)})`, fontFamily: FONT, fontWeight: 900, fontSize: 170, color: YELLOW, textShadow: '0 10px 50px rgba(0,0,0,0.9)', WebkitTextStroke: '4px rgba(0,0,0,0.5)', whiteSpace: 'nowrap'}}>+ US$ 20</div>
      )}
    </AbsoluteFill>
  );
};

// ---------- calendário de 52 semanas ----------
export const SCalendario = ({t, keys, t0, t1, children}) => {
  const cam = camK(keys, t);
  const k = Math.floor(52 * clamp01((t - t0) / (t1 - t0)) + 0.0001);
  const tiles = [...Array(52)].map((_, i) => ({p: [(i % 13 - 6) * 1.05, 0.06, (Math.floor(i / 13) - 1.5) * 1.05], on: i < k}));
  return (
    <Palco cam={cam} fog={['#0d2f38', 14, 50]}>
      <Chao />
      <spotLight position={[0, 14, 6]} angle={0.6} penumbra={0.6} intensity={380} distance={45} color="#ffd890" />
      <Instancias items={tiles.filter((x) => !x.on).map((x) => ({p: x.p}))} geo={<boxGeometry args={[0.95, 0.12, 0.95]} />} cor="#2c6170" />
      {k > 0 && <Instancias items={tiles.filter((x) => x.on).map((x) => ({p: x.p}))} geo={<boxGeometry args={[0.95, 0.12, 0.95]} />} cor="#3a7f5a" emissive="#2f9e5b" ei={0.3} />}
      {k > 0 && <Instancias items={tiles.filter((x) => x.on).map((x, i) => {
        const tc = t0 + i * (t1 - t0) / 52, q = clamp01((t - tc) / 0.25);
        return {p: [x.p[0], 0.18 + (1 - q) * 2.5, x.p[2]], r: [0, 0, 0]};
      })} geo={<cylinderGeometry args={[0.32, 0.32, 0.08, 20]} />} cor="#ffc93c" emissive="#ffb300" ei={0.6} metalness={0.4} roughness={0.4} />}
      {children}
    </Palco>
  );
};

// ---------- duas barras ----------
export const SBarras = ({t, keys, ta, tb, ha = 0.35, hb = 11, children}) => {
  const cam = camK(keys, t);
  const a = ha * ease(clamp01((t - ta) / 0.8));
  const b = hb * ease(clamp01((t - tb) / 1.6));
  return (
    <Palco cam={cam} fog={['#0d2f38', 16, 60]}>
      <Chao />
      <spotLight position={[0, 20, 10]} angle={0.6} penumbra={0.7} intensity={500} distance={60} color="#ffd890" />
      {a > 0.01 && <mesh position={[-2, a / 2, 0]}><boxGeometry args={[2.2, a, 2.2]} /><meshStandardMaterial color="#5f8fa0" /></mesh>}
      {b > 0.01 && <mesh position={[2, b / 2, 0]}><boxGeometry args={[2.2, b, 2.2]} /><meshStandardMaterial color={OURO} emissive="#b07800" emissiveIntensity={0.5} metalness={0.3} roughness={0.45} /></mesh>}
      {children}
    </Palco>
  );
};

// ---------- árvore de indicações (radial no chão) ----------
const arvore = (() => {
  const nos = [{p: [0, 0], nv: 0, pai: -1}];
  let atual = [0];
  for (let nv = 1; nv <= 5; nv++) {
    const prox = [];
    atual.forEach((pi) => {
      for (let k = 0; k < 3; k++) {
        const idx = nos.length;
        const tot = Math.pow(3, nv), j = prox.length;
        const ang = (j + 0.5) / tot * Math.PI * 2 + nv * 0.3;
        const r = nv * 1.6;
        nos.push({p: [Math.cos(ang) * r, Math.sin(ang) * r], nv, pai: pi});
        prox.push(idx);
      }
    });
    atual = prox;
  }
  return nos;
})();
export const SArvore = ({t, keys, niveis, bonus, vermelho = 0, children}) => {
  const cam = camK(keys, t);
  const nv = niveis(t);
  const vis = arvore.filter((n) => n.nv <= nv);
  const linhas = vis.filter((n) => n.pai >= 0).map((n) => {
    const a = arvore[n.pai].p, b = n.p;
    const g = clamp01(nv - n.nv + 1);
    const ex = lerp(a[0], b[0], g), ez = lerp(a[1], b[1], g);
    const dx = ex - a[0], dz = ez - a[1], L = Math.hypot(dx, dz);
    return {p: [(a[0] + ex) / 2, 0.03, (a[1] + ez) / 2], s: [L, 1, 1], r: [0, -Math.atan2(dz, dx), 0]};
  });
  const gente = vis.filter((n) => nv - n.nv > -0.2).map((n, i) => ({p: [n.p[0], 0, n.p[1]], c: n.nv === 0 ? '#ffd54f' : CORES[i % CORES.length], s: n.nv === 0 ? 2.2 : 1.5}));
  const moedas = bonus != null && t > bonus ? vis.filter((n) => n.nv >= 1).slice(0, 120).map((n, i) => {
    const u = ((t - bonus) * 0.8 + rnd(i) ) % 1;
    return {p: [lerp(n.p[0], 0, u), 0.6 + Math.sin(u * Math.PI) * 1.2, lerp(n.p[1], 0, u)], r: [Math.PI / 2, 0, 0]};
  }) : [];
  return (
    <Palco cam={cam} fog={['#0d2f38', 14, 60]}>
      <Chao />
      <spotLight position={[0, 18, 4]} angle={0.7} penumbra={0.7} intensity={460} distance={60} color="#ffd890" />
      {vermelho > 0 && <pointLight position={[0, 5, 0]} intensity={150 * vermelho} distance={30} color="#ff2a1a" />}
      {linhas.length > 0 && <Instancias items={linhas} geo={<boxGeometry args={[1, 0.03, 0.05]} />} cor="#ffd54f" emissive="#ffb300" ei={1} />}
      <Multidao items={gente} />
      {moedas.length > 0 && <Instancias items={moedas} geo={<cylinderGeometry args={[0.12, 0.12, 0.04, 14]} />} cor="#ffc93c" emissive="#ffb300" ei={0.9} />}
      {children}
    </Palco>
  );
};

// ---------- martelo batendo; pirâmide congela atrás ----------
export const SMartelo = ({t, keys, bate, n = 7, children}) => {
  const cam = camK(keys, t);
  const sobe = rampa(t, bate - 1.6, bate - 0.25);
  const desce = clamp01((t - (bate - 0.12)) / 0.12);
  const ang = desce > 0 ? lerp(-0.9, 0, desce * desce) : lerp(0, -0.9, sobe);
  const tr = t > bate && t < bate + 0.25 ? Math.sin((t - bate) * 90) * 0.04 * (1 - (t - bate) / 0.25) : 0;
  const cg = rampa(t, bate, bate + 1.0);
  return (
    <Palco cam={{...cam, pos: [cam.pos[0] + tr, cam.pos[1] + tr, cam.pos[2]]}} fog={['#0d2f38', 14, 60]}>
      <Chao />
      <spotLight position={[3, 10, 8]} angle={0.5} penumbra={0.6} intensity={300} distance={40} color={cg > 0.5 ? '#bfe3ff' : '#ffd890'} />
      <group position={[0, 0, -8]}><Piramide n={n} congela={cg} cor={new THREE.Color(OURO).lerp(new THREE.Color('#7fb8d8'), cg).getStyle()} /></group>
      <mesh position={[0, 0.25, 2]}><cylinderGeometry args={[0.9, 1.0, 0.5, 32]} /><meshStandardMaterial color="#6d3f1f" roughness={0.5} /></mesh>
      <group position={[1.8, 1.0, 2]} rotation={[0, 0, ang]}>
        <Martelo p={[-1.8, 0, 0]} s={1} />
      </group>
      {t > bate && t < bate + 0.6 && <mesh position={[0, 0.52, 2]} rotation={[-Math.PI / 2, 0, 0]} scale={0.5 + (t - bate) * 5}><torusGeometry args={[1, 0.04, 6, 40]} /><meshBasicMaterial color="#ffffff" transparent opacity={0.8 * (1 - (t - bate) / 0.6)} /></mesh>}
      {children}
    </Palco>
  );
};

// ---------- bens bloqueados: pilhas e grade que desce ----------
export const SGaiola = ({t, keys, t0, children}) => {
  const cam = camK(keys, t);
  const g = clamp01((t - t0) / 0.35);
  const y = lerp(6, 0, g * g);
  return (
    <Palco cam={cam} fog={['#0d2f38', 12, 45]}>
      <Chao />
      <spotLight position={[0, 12, 6]} angle={0.5} penumbra={0.6} intensity={360} distance={40} color="#ffd890" />
      {[[-1.2, 0, 1.6], [0, -0.6, 2.4], [1.2, 0.2, 1.3], [-0.4, 1.0, 1.0], [0.8, -1.2, 0.8]].map(([x, z, h], i) => <Pilha key={i} p={[x, 0, z]} h={h} r={0.45} />)}
      <group position={[0, y, 0]}>
        {[...Array(14)].map((_, i) => {
          const a = (i / 14) * Math.PI * 2;
          return <mesh key={i} position={[Math.cos(a) * 2.6, 1.6, Math.sin(a) * 2.6]}><cylinderGeometry args={[0.05, 0.05, 3.2, 8]} /><meshStandardMaterial color="#b0bec5" metalness={0.7} roughness={0.3} /></mesh>;
        })}
        <mesh position={[0, 3.2, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[2.6, 0.07, 8, 48]} /><meshStandardMaterial color="#b0bec5" metalness={0.7} roughness={0.3} /></mesh>
        <mesh position={[0, 0.05, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[2.6, 0.07, 8, 48]} /><meshStandardMaterial color="#b0bec5" metalness={0.7} roughness={0.3} /></mesh>
      </group>
      {g >= 1 && <pointLight position={[0, 2, 3]} intensity={40} distance={10} color="#ff3020" />}
      {children}
    </Palco>
  );
};

// ---------- a pessoa, as economias, a dívida e a família ----------
export const SFamilia = ({t, keys, tPilha, tDivida, tFam, tSome, tVira, children}) => {
  const cam = camK(keys, t);
  const hp = 1.4 * ease(clamp01((t - tPilha) / 0.8)) * (1 - ease(clamp01((t - tSome) / 0.8)));
  const div = sp(t, tDivida) * (1 - ease(clamp01((t - tSome) / 0.8)) * 0);
  const fam = [[-3, 0, 1.2], [3, 0, 1.0], [0.2, 0, -3]];
  const cinza = rampa(t, tVira, tVira + 0.8);
  return (
    <Palco cam={cam} fog={['#0d2f38', 12, 45]}>
      <Chao />
      <spotLight position={[0, 12, 5]} angle={0.45} penumbra={0.6} intensity={lerp(360, 160, cinza)} distance={40} color="#ffd890" />
      {cinza > 0 && <pointLight position={[0, 3, 2]} intensity={40 * cinza} distance={12} color="#ff3020" />}
      <Pilha p={[0, 0, 0]} h={hp} r={0.7} />
      <Boneco p={[0, hp, 0]} c="#ffd54f" s={2.2} />
      {div > 0.01 && <mesh position={[1.4, 0.35 * div, 0.4]} scale={div}><boxGeometry args={[0.8, 0.7, 0.8]} /><meshStandardMaterial color="#c62828" emissive="#7a0000" emissiveIntensity={0.5} /></mesh>}
      {fam.map((f, i) => {
        const p = sp(t, tFam + i * 0.6);
        if (p < 0.01) return null;
        const L = Math.hypot(f[0], f[2]) * p;
        const ang = Math.atan2(f[2], f[0]);
        return (
          <group key={i}>
            <Boneco p={f} c={new THREE.Color(CORES[i]).lerp(new THREE.Color('#555'), cinza).getStyle()} s={1.9 * p} r={-ang - Math.PI / 2} />
            <mesh position={[Math.cos(ang) * L / 2, 0.05, Math.sin(ang) * L / 2]} rotation={[0, -ang, 0]}><boxGeometry args={[L, 0.03, 0.06]} /><meshStandardMaterial color={cinza > 0.5 ? '#ff5a4a' : '#ffd54f'} emissive={cinza > 0.5 ? '#ff2a1a' : '#ffb300'} emissiveIntensity={1} /></mesh>
          </group>
        );
      })}
      {children}
    </Palco>
  );
};

// ---------- a roda que não pode parar ----------
export const SRoda = ({t, keys, para, children}) => {
  const cam = camK(keys, t);
  const v = 1 - rampa(t, para, para + 1.2);
  // ângulo integrado (velocidade cai até zero)
  const ang = t < para ? t * 0.9 : para * 0.9 + 0.9 * (1.2 / 2) * (1 - Math.pow(1 - clamp01((t - para) / 1.2), 2));
  const vermelho = rampa(t, para + 0.6, para + 1.4);
  return (
    <Palco cam={cam} fog={['#0d2f38', 12, 50]}>
      <Chao />
      <spotLight position={[0, 14, 7]} angle={0.5} penumbra={0.6} intensity={420} distance={45} color="#ffd890" />
      {vermelho > 0 && <pointLight position={[0, 1.5, 5]} intensity={120 * vermelho} distance={16} color="#ff2a1a" />}
      <group position={[0, 3.2, 0]} rotation={[0, 0, -ang]}>
        <mesh><torusGeometry args={[3, 0.12, 10, 80]} /><meshStandardMaterial color={OURO} emissive="#b07800" emissiveIntensity={0.5} metalness={0.4} roughness={0.4} /></mesh>
        {[...Array(12)].map((_, i) => <mesh key={i} rotation={[0, 0, (i / 12) * Math.PI * 2]} position={[0, 0, 0]}><boxGeometry args={[6, 0.05, 0.05]} /><meshStandardMaterial color="#c9a227" /></mesh>)}
        {[...Array(24)].map((_, i) => { const a = (i / 24) * Math.PI * 2; return <mesh key={`r${i}`} position={[Math.cos(a) * 3, Math.sin(a) * 3, 0]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.04, 0.04, 1.6, 6]} /><meshStandardMaterial color="#e0c060" /></mesh>; })}
      </group>
      {[-0.5, 0, 0.5].map((z, i) => <Boneco key={i} p={[-0.2 + i * 0.35, 0.2 + Math.abs(Math.sin(t * 10 * v + i)) * 0.08 * v, z]} c={CORES[i]} s={1.8} r={Math.PI / 2} />)}
      <mesh position={[0, 0.1, 0]}><boxGeometry args={[0.4, 0.2, 2]} /><meshStandardMaterial color="#444" /></mesh>
      {children}
    </Palco>
  );
};

// ---------- cela: grades que descem ----------
export const SCela = ({t, keys, desce, sobe = 1e9, children}) => {
  const cam = camK(keys, t);
  const g = clamp01((t - desce) / 0.3) * (1 - rampa(t, sobe, sobe + 0.6));
  return (
    <Palco cam={cam} fog={['#0d2f38', 10, 40]}>
      <Chao c="#122e36" />
      <spotLight position={[0, 9, 2]} angle={0.35} penumbra={0.5} intensity={260} distance={30} color="#e8f4ff" />
      <Boneco p={[0, 0, 0]} c="#5b6770" s={2.4} />
      <Forum p={[0, 0, -5]} s={0.9} janela={0.6} />
      <group position={[0, lerp(5, 0, g * g), 1.5]}>
        {[...Array(11)].map((_, i) => <mesh key={i} position={[-2.5 + i * 0.5, 1.7, 0]}><cylinderGeometry args={[0.05, 0.05, 3.4, 8]} /><meshStandardMaterial color="#9aa7ad" metalness={0.8} roughness={0.3} /></mesh>)}
        {[0.2, 3.3].map((y) => <mesh key={y} position={[0, y, 0]}><boxGeometry args={[5.4, 0.12, 0.12]} /><meshStandardMaterial color="#9aa7ad" metalness={0.8} roughness={0.3} /></mesh>)}
      </group>
      {children}
    </Palco>
  );
};

// ---------- moeda-pizza (fração) ----------
export const SPizza = ({t, keys, t0, frac = 0.4, children}) => {
  const cam = camK(keys, t);
  const f = frac * ease(clamp01((t - t0) / 1.2));
  return (
    <Palco cam={cam} fog={['#0d2f38', 12, 40]}>
      <Chao />
      <spotLight position={[0, 12, 6]} angle={0.5} penumbra={0.6} intensity={400} distance={40} color="#ffd890" />
      <group position={[0, 0.4, 0]} rotation={[0, t * 0.15, 0]}>
        <mesh><cylinderGeometry args={[3, 3, 0.5, 64, 1, false, 0, Math.PI * 2]} /><meshStandardMaterial color="#2c4c55" roughness={0.7} /></mesh>
        {f > 0.005 && <mesh position={[0, 0.06, 0]}><cylinderGeometry args={[3.02, 3.02, 0.62, 64, 1, false, 0, Math.PI * 2 * f]} /><meshStandardMaterial color={OURO} emissive="#b07800" emissiveIntensity={0.5} metalness={0.4} roughness={0.4} /></mesh>}
      </group>
      {children}
    </Palco>
  );
};
