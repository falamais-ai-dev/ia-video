// Piloto: A História Secreta do Maior Golpe Financeiro do Brasil (Telexfree). Sem legenda.
import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';
import {FPS, W, H, FONT, YELLOW, clamp01, lerp, projeta, Vinheta, setFmt, FMT} from './comum';
import {Marca, Faixas, Boneco, CORES} from './kit';
import {BLOCOS, CAPS, CARD, TITULO, TOTAL} from './tempo.mjs';
import {Tag, Num, Carimbo, FonteTxt, Simulacao, VERM, rampa, camK, sp} from './base';
import {SCidade, SDoc, SCelulares, STelefone, SMultidao, SPiramide, SGlobo, SMapa, SRua} from './cenasA';
import {SPilhas, SCatraca, SKits, STela, SCalendario, SBarras, SArvore, SMartelo, SGaiola, SFamilia, SRoda, SCela, SPizza} from './cenasB';
import {SLinha, SFecho, Titulo, Cartao} from './cenasC';

const R = Math.PI / 180;
const face = (lon) => -Math.PI / 2 - lon * R; // gira o globo para mostrar a longitude
const fmt = (n) => Math.round(n).toLocaleString('pt-BR');
const pw = (t, keys) => { // valor por trechos lineares
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 0; i < keys.length - 1; i++) if (t <= keys[i + 1][0]) return lerp(keys[i][1], keys[i + 1][1], clamp01((t - keys[i][0]) / (keys[i + 1][0] - keys[i][0])));
  return keys[keys.length - 1][1];
};
const Escuro = ({o = 0.4}) => <AbsoluteFill style={{background: `rgba(0,0,0,${o})`}} />;

// ===================== ABERTURA =====================
const S0 = [
  [0, (t) => <>
    <SCidade t={t} keys={[{t: 0, p: [0, 24, 32], l: [0, 0, -2]}, {t: 3.4, p: [2.5, 4.2, 9], l: [1, 2, 0]}]} />
    <Tag t={t} t0={0.2} x={110} y={210} txt="RIO BRANCO, ACRE" sub="JUNHO DE 2013" />
  </>],
  [3.3, (t) => <>
    <SDoc t={t} t0={3.35} t1={8.1} titulo="DECISÃO JUDICIAL" sub="2ª VARA CÍVEL · RIO BRANCO (AC)" linhas={7} />
    <Carimbo t={t} t0={6.75} txt="SUSPENSO" x={W / 2 + 230} y={H / 2 + 170} rot={-12} size={84} />
  </>],
  [8.1, (t) => <>
    <SCelulares t={t} t0={9.5} keys={[{t: 8.1, p: [0, 6.5, 4.5], l: [0, 0, 0]}, {t: 11.6, p: [0.5, 4.6, 2.8], l: [0, 0, 0]}]} />
    <Tag t={t} t0={10.3} x={110} y={180} txt="AMEAÇAS DE MORTE" cor={VERM} size={52} />
  </>],
  [11.6, (t) => <>
    <SCidade t={t} gente={lerp(0, 520, rampa(t, 11.7, 14.2))} placas pula={t > 14.6} sangue={rampa(t, 14.6, 15.6)}
      keys={[{t: 11.6, p: [0, 2.4, 15], l: [0, 1.8, 0]}, {t: 17.4, p: [3.5, 3.4, 11.5], l: [0, 2.2, -1]}]} />
    <Tag t={t} t0={15.0} x={110} y={180} txt="OS PRÓPRIOS DIVULGADORES" cor={VERM} />
  </>],
  [17.4, (t) => <>
    <STelefone t={t} ondas={[17.5, 21.0]} apaga={21.0} keys={[{t: 17.4, p: [0, 3.2, 7.5], l: [0, 1.3, 0]}, {t: 22.3, p: [2.6, 2.2, 4.6], l: [0, 1.4, 0]}]} />
    <Tag t={t} t0={18.9} t1={20.9} x={110} y={180} txt="TELEFONE PELA INTERNET" />
    <Tag t={t} t0={21.2} x={110} y={180} txt="QUE QUASE NÃO VENDIA TELEFONE" cor={VERM} />
  </>],
  [22.3, (t) => <>
    <SMultidao t={t} t0={22.4} t1={24.4} keys={[{t: 22.3, p: [0, 2.6, 6], l: [0, 0.6, 0]}, {t: 25.5, p: [0, 34, 28], l: [0, 0, 0]}]} />
    <Num t={t} t0={24.1} txt="≈ 1 MILHÃO" sub="DE BRASILEIROS" y={250} />
  </>],
  [25.5, (t) => <>
    <SPiramide t={t} n={lerp(1, 8, rampa(t, 25.6, 30.6))} keys={[{t: 25.5, p: [13, 6, 23], l: [0, 2.6, 0]}, {t: 33, p: [7, 3.2, 15], l: [0, 2.4, 0]}]} />
  </>],
];

// título (depois da abertura)
const TituloCena = ({lt}) => (
  <>
    <SPiramide t={lt} n={8} keys={[{t: 0, p: [8, 4, 17], l: [0, 2.8, 0]}, {t: TITULO, p: [6, 3.8, 15], l: [0, 2.8, 0]}]} />
    <Escuro o={0.55} />
    <Titulo lt={lt} dur={TITULO} />
  </>
);

// ===================== 1. A PROMESSA =====================
const EUA = [-71.8, 42.3], VIX = [-40.3, -20.3], BR = [-47.9, -15.8];
const S1 = [
  [0, (t) => <>
    <SGlobo t={t} rot={(t) => [lerp(0.6, -0.05, rampa(t, 0.5, 4)), lerp(face(-78), face(-52), rampa(t, 0.5, 4))]}
      arcos={[{a: EUA, b: VIX, t0: 1.2, t1: 3.4, h: 0.3}]} pontos={[{lon: EUA[0], lat: EUA[1], t0: 0.6, cor: YELLOW}, {lon: VIX[0], lat: VIX[1], t0: 3.3, cor: YELLOW}]}
      keys={[{t: 0, p: [0, 0, 11], l: [0, 0, 0]}, {t: 4.4, p: [0, -0.3, 9], l: [0, 0, 0]}]} />
    <Tag t={t} t0={0.2} x={110} y={200} txt="2012" size={56} />
    <Tag t={t} t0={3.4} x={110} y={330} txt="TELEXFREE" sub="EMPRESA AMERICANA" />
  </>],
  [4.4, (t) => <>
    <STelefone t={t} ondas={[4.4, 8]} giro={0.4} keys={[{t: 4.4, p: [3.5, 2.8, 6], l: [0, 1.3, 0]}, {t: 7.9, p: [-2.5, 2.2, 5.2], l: [0, 1.4, 0]}]} />
    <Tag t={t} t0={5.0} x={110} y={180} txt="LIGAÇÃO PELA INTERNET" sub="VoIP" />
  </>],
  [7.9, (t) => <>
    <SGlobo t={t} rot={(t) => [0.15, face(-40) + (t - 7.9) * 0.08]}
      arcos={[[-9.1, 38.7], [-74, 40.7], [13.2, -8.8], [-58.4, -34.6], [-0.1, 51.5], [-99, 19.4], [3.4, 6.5]].map((b, i) => ({a: BR, b, t0: 8.2 + i * 0.4, t1: 9.2 + i * 0.4, h: 0.12}))}
      keys={[{t: 7.9, p: [0, 0.5, 9.5], l: [0, 0, 0]}, {t: 13.1, p: [1, 0.3, 8.6], l: [0, 0, 0]}]} />
  </>],
  [13.1, (t) => <>
    <SCatraca t={t} gira={16.9} keys={[{t: 13.1, p: [3.5, 2.4, 6.5], l: [0, 1, 0]}, {t: 17.9, p: [2.8, 2.6, 5.8], l: [0, 1.0, 0]}]} />
    <Num t={t} t0={16.7} txt="US$ 50" sub="TAXA PRA ENTRAR" x={W / 2} y={250} size={150} />
  </>],
  [17.9, (t) => <>
    <SKits t={t} a={19.3} b={22.9} keys={[{t: 17.9, p: [0, 3.4, 10], l: [0, 1.1, 0]}, {t: 25.5, p: [0.4, 2.6, 7.8], l: [0.2, 1.2, 0]}]} />
    <Num t={t} t0={21.0} txt="US$ 289" sub="KIT MAIS BARATO" x={560} y={220} size={110} />
    <Num t={t} t0={23.7} txt="US$ 1.375" sub="KIT MAIOR" x={1340} y={200} size={110} />
  </>],
  [25.5, (t) => <>
    <STela t={t} t0={25.5} copia={31.2} cola={31.8} dias={33.3} paga={36.2} />
    <Tag t={t} t0={27.1} t1={33.0} x={110} y={160} txt="1 ANÚNCIO POR DIA" sub="EM SITE DE CLASSIFICADOS GRÁTIS" />
  </>],
  [38.0, (t) => {
    const k = Math.floor(52 * clamp01((t - 39.2) / (41.8 - 39.2)) + 0.0001);
    return <>
      <SCalendario t={t} t0={39.2} t1={41.8} keys={[{t: 38, p: [0, 10, 9.5], l: [0, 0, 0.3]}, {t: 43.6, p: [1.5, 7.5, 7], l: [0, 0, 0.3]}]} />
      {t > 39.1 && <div style={{position: 'absolute', left: FMT.w / 2, top: FMT.v ? 560 : 170, transform: 'translateX(-50%)', fontFamily: FONT, fontWeight: 900, fontSize: 120, color: YELLOW, textShadow: '0 8px 40px rgba(0,0,0,0.9)', whiteSpace: 'nowrap'}}>US$ {fmt(k * 20)}</div>}
      {t > 39.1 && <div style={{position: 'absolute', left: FMT.w / 2, top: FMT.v ? 700 : 320, transform: 'translateX(-50%)', fontFamily: FONT, fontWeight: 800, fontSize: 34, letterSpacing: 6, color: 'white', textShadow: '0 2px 12px black'}}>SEMANA {Math.max(1, k)} DE 52</div>}
    </>;
  }],
  [43.6, (t) => <>
    <SPilhas t={t} pilhas={[{x: -2.2, h: 1.6 * rampa(t, 43.8, 44.5), r: 1.0}, {x: 2.2, h: 5.76 * rampa(t, 45.8, 46.6), r: 1.0}]}
      keys={[{t: 43.6, p: [0, 2.2, 9], l: [0, 1.4, 0]}, {t: 46.9, p: [0, 3.2, 10.5], l: [0, 2.4, 0]}]} />
    <Num t={t} t0={44.3} txt="US$ 289" sub="VOCÊ COLOCOU" x={560} y={250} size={100} cor="white" />
    <Num t={t} t0={46.1} txt="US$ 1.040" sub="VOLTA EM 1 ANO" x={1360} y={250} size={100} />
  </>],
  [46.9, (t) => <>
    <SBarras t={t} ta={48.6} tb={52.3} ha={0.25} hb={11} keys={[{t: 46.9, p: [0, 2.5, 13], l: [0, 1.5, 0]}, {t: 52.2, p: [0, 3, 13], l: [0, 2, 0]}, {t: 53.9, p: [0, 7, 19], l: [0, 5.2, 0]}]} />
    <Num t={t} t0={49.9} txt="< 6%" sub="POUPANÇA EM 2013" x={600} y={300} size={110} cor="#9fd3e0" />
    <Num t={t} t0={52.5} txt="> 200%" sub="NA TELEXFREE" x={1380} y={300} size={110} />
  </>],
  [53.9, (t) => <>
    <SArvore t={t} niveis={(t) => pw(t, [[54.6, 0], [56.9, 1], [58.5, 2], [60.3, 3]])} bonus={60.8}
      keys={[{t: 53.9, p: [0, 4, 6.5], l: [0, 0.4, 0]}, {t: 61.5, p: [0, 13, 12], l: [0, 0, 0]}]} />
    <Tag t={t} t0={56.8} x={110} y={180} txt="TRAZER GENTE NOVA" />
    <Tag t={t} t0={60.8} x={110} y={300} txt="BÔNUS POR INDICAÇÃO" />
  </>],
  [61.5, (t) => <>
    <STelefone t={t} apaga={61.0} giro={0.1} keys={[{t: 61.5, p: [2, 2.3, 4.6], l: [0, 1.2, 0]}, {t: 65.4, p: [0.6, 1.7, 3.2], l: [0, 1.2, 0]}]} />
    <Tag t={t} t0={62.8} x={110} y={180} txt="NINGUÉM PRECISAVA VENDER TELEFONE" cor={VERM} />
  </>],
  [65.4, (t) => <>
    <SArvore t={t} niveis={(t) => pw(t, [[65.4, 3], [66.4, 4], [68.0, 5]])} bonus={65.4} vermelho={rampa(t, 68.0, 69.6)}
      keys={[{t: 65.4, p: [0, 13, 12], l: [0, 0, 0]}, {t: 70.5, p: [0, 20, 18], l: [0, 0, 0]}]} />
  </>],
];

// ===================== 2. A FEBRE =====================
const ES = {cor: '#f2b830', emis: 0.6};
const S2 = [
  [0, (t) => <>
    <SMapa t={t} destaque={{'Espírito Santo': {...ES, alt: 0.25 + 0.7 * rampa(t, 1.4, 2.2)}}} pulsos={[{lon: VIX[0], lat: VIX[1], t0: 1.4, cor: YELLOW}]}
      keys={[{t: 0, p: [8, 8, 10], l: [4.8, 0, 2.4]}, {t: 5.8, p: [6.2, 5.2, 7.2], l: [4.8, 0, 2.4]}]} />
    <Tag t={t} t0={1.4} x={110} y={200} txt="VITÓRIA (ES)" />
    <Tag t={t} t0={4.7} x={110} y={330} txt="YMPACTUS" sub="A EMPRESA NO BRASIL" />
  </>],
  [5.8, (t) => <>
    <SMapa t={t} destaque={{'Espírito Santo': {...ES, alt: 0.95}}} pontos={{n: 1100, de: VIX, t0: 6.0, t1: 13.3}}
      keys={[{t: 5.8, p: [6, 9, 9], l: [3, 0, 2]}, {t: 13.3, p: [0, 23, 12], l: [0, 0, 0.6]}, {t: 15.1, p: [-1, 22, 11], l: [-0.5, 0, 0.4]}]} />
    <Tag t={t} t0={8.0} x={110} y={200} txt="AMIGO" size={36} />
    <Tag t={t} t0={8.6} x={110} y={290} txt="PARENTE" size={36} />
    <Tag t={t} t0={9.6} x={110} y={380} txt="VIZINHO" size={36} />
    <Num t={t} t0={13.2} txt="≈ 1 MILHÃO" sub="DE DIVULGADORES NO BRASIL" x={W - 520} y={250} size={110} />
  </>],
  [15.1, (t) => <>
    <SMapa t={t} destaque={{'Espírito Santo': {...ES, alt: 0.95}, Acre: {cor: '#ff5a3a', emis: 0.7 * rampa(t, 17.2, 17.9), alt: 0.25 + 1.0 * rampa(t, 17.2, 18.2)}}}
      pontos={{n: 1100, de: VIX, t0: -10, t1: -9}} pulsos={[{lon: -67.8, lat: -9.97, t0: 17.3, cor: '#ff5a3a'}]}
      keys={[{t: 15.1, p: [-1, 22, 11], l: [-0.5, 0, 0.4]}, {t: 17.4, p: [-5, 10, 6.5], l: [-7, 0, -1.5]}, {t: 27.2, p: [-6.5, 8, 5], l: [-7.4, 0.3, -1.8]}]} />
    <Tag t={t} t0={17.2} x={110} y={180} txt="ACRE" size={56} cor="#ff5a3a" />
    <Tag t={t} t0={19.4} x={110} y={310} txt="MENOS DE 800 MIL HABITANTES" />
    <Tag t={t} t0={22.6} x={110} y={430} txt="≈ 40 MIL NO NEGÓCIO" cor="#ff5a3a" />
    <Num t={t} t0={25.8} txt="1 EM CADA 20" x={W - 560} y={760} size={120} cor="#ff8a6a" />
  </>],
  [27.2, (t) => <>
    <SRua t={t} acende={29.8} idx={12} keys={[{t: 27.2, p: [-3, 1.8, 6.5], l: [3, 0.8, 0]}, {t: 29.7, p: [15.5, 1.8, 6.0], l: [18, 0.7, 0]}, {t: 34, p: [18, 1.3, 3.6], l: [18, 0.6, 0]}]} />
    <Tag t={t} t0={32.3} x={110} y={180} txt="US$ 20 POR SEMANA" />
  </>],
  [34.0, (t) => <>
    <SFamilia t={t} tPilha={35.7} tDivida={1e9} tFam={38.6} tSome={1e9} tVira={1e9} keys={[{t: 34, p: [0, 1.8, 4.2], l: [0, 1.2, 0]}, {t: 39.8, p: [2.5, 4.2, 8.5], l: [0, 0.8, 0]}]} />
    <Tag t={t} t0={37.1} x={110} y={180} txt="QUEM ENTROU CEDO RECEBEU" />
  </>],
  [39.8, (t) => <>
    <SPiramide t={t} n={6} moedas vermelho={rampa(t, 42.4, 44.4)} keys={[{t: 39.8, p: [2.5, 6.5, 5.5], l: [0, 3.2, 0]}, {t: 45.6, p: [11, 6, 19], l: [0, 2, 0]}]} />
    <Num t={t} t0={43.7} txt="DE ONDE VINHA?" size={120} y={250} />
  </>],
];

// ===================== 3. A CONTA QUE NÃO FECHA =====================
const TORRE_H = 24;
const S3 = [
  [0, (t) => <>
    <SPilhas t={t} pilhas={[{x: 4.2, h: 0.9 * rampa(t, 19.2, 19.8), r: 0.4}]} torre={{x: 0, w: 4, h: TORRE_H * rampa(t, 0.2, 12.0)}}
      keys={[{t: 0, p: [3, 1.5, 10], l: [0, 0.8, 0]}, {t: 4, p: [3, 3, 15], l: [0, 2.5, 0]}, {t: 12.5, p: [6, 12, 36], l: [0, 11, 0]}, {t: 15.5, p: [8, 10, 32], l: [2, 8, 0]},
        {t: 19.3, p: [6.5, 1.5, 4.5], l: [4.2, 0.4, 0]}, {t: 23.5, p: [6.8, 1.7, 5.2], l: [4.2, 0.5, 0]}, {t: 29.2, p: [10, 8, 30], l: [1.5, 8, 0]}]} />
    <Tag t={t} t0={4.6} t1={10.8} x={110} y={180} txt="SEC" sub="A CVM DOS ESTADOS UNIDOS" />
    <Num t={t} t0={11.4} t1={15.0} txt="US$ 1,1 BILHÃO" sub="O QUE A EMPRESA PRECISARIA" y={240} size={130} />
    <Tag t={t} t0={14.2} t1={19.0} x={110} y={180} txt="VENDA DE TELEFONE" sub="AGO/2012 A MAR/2014" />
    <Num t={t} t0={19.4} t1={21.2} txt="US$ 1,3 MILHÃO" sub="FATURADO COM TELEFONE" y={240} size={120} />
    <Num t={t} t0={21.45} t1={24.0} txt="< 1%" sub="DO QUE PRECISAVA" y={300} size={230} cor="#ff8a6a" />
    <Tag t={t} t0={24.6} x={110} y={180} txt="A CADA US$ 1.000 PROMETIDOS" />
    <Tag t={t} t0={26.6} x={110} y={300} txt="≈ US$ 1 VINHA DO TELEFONE" cor="#ff8a6a" />
    <FonteTxt t={t} t0={4.6} txt="SEC, processo de abril de 2014" />
  </>],
  [29.2, (t) => <>
    <SPiramide t={t} n={6} fila moedas keys={[{t: 29.2, p: [11, 1.4, 8], l: [4, 0.9, 1.5]}, {t: 34.6, p: [9, 3.6, 13], l: [0, 2, 0]}]} />
    <Tag t={t} t0={32.4} x={110} y={180} txt="DO DINHEIRO DE QUEM ACABAVA DE ENTRAR" />
  </>],
  [34.6, (t) => <>
    <SPiramide t={t} n={8} luzTopo={1 + 2 * rampa(t, 35.8, 36.2)} keys={[{t: 34.6, p: [4, 7, 8], l: [0, 4, 0]}, {t: 35.9, p: [12, 6, 22], l: [0, 2.5, 0]}, {t: 43.8, p: [-10, 4, 18], l: [0, 2.5, 0]}]} />
    <Num t={t} t0={35.9} t1={38.6} txt="PIRÂMIDE" size={190} y={260} />
    {t > 41.1 && <Simulacao />}
  </>],
  [43.8, (t) => {
    const n = pw(t, [[43.8, 1], [47.4, 1], [47.8, 2], [48.9, 2], [49.4, 3], [50.1, 3], [51.0, 6], [52.1, 6], [53.2, 11], [54.4, 11], [57.2, 13]]);
    const NV = [[47.6, 1, 5], [49.1, 2, 25], [50.8, 5, 3125], [52.9, 10, 9765625], [57.0, 12, 244140625]];
    const cur = NV.filter((x) => t >= x[0]).pop();
    return <>
      <SPiramide t={t} n={n} NIV={13} HN={0.5} w0={0.5} dw={0.85} gente={false}
        keys={[{t: 43.8, p: [2.5, 1.2, 4.5], l: [0, 0.3, 0]}, {t: 48, p: [4, 2.2, 7], l: [0, 0.8, 0]}, {t: 51.5, p: [9, 4.2, 17], l: [0, 1.8, 0]}, {t: 57.5, p: [13, 7.5, 28], l: [0, 3.2, 0]}, {t: 62.4, p: [14, 8, 30], l: [0, 3.2, 0]}]} />
      <Simulacao />
      <Tag t={t} t0={45.2} x={110} y={200} txt="CADA UM TRAZ 5" />
      {cur && <div style={{position: 'absolute', right: 90, top: FMT.v ? 520 : 150, textAlign: 'right', fontFamily: FONT, color: 'white', transform: `scale(${0.9 + 0.1 * sp(t, cur[0])})`, transformOrigin: 'right top'}}>
        <div style={{fontWeight: 800, fontSize: 40, letterSpacing: 6, color: '#9fd3e0'}}>NÍVEL {cur[1]}</div>
        <div style={{fontWeight: 900, fontSize: 110, color: cur[1] >= 12 ? '#ff8a6a' : YELLOW, textShadow: '0 6px 30px rgba(0,0,0,0.9)'}}>{fmt(cur[2])}</div>
        <div style={{fontWeight: 700, fontSize: 30, letterSpacing: 4}}>PESSOAS</div>
      </div>}
      {t > 60.0 && !FMT.v && <div style={{position: 'absolute', left: 110, top: 740, width: 1300, fontFamily: FONT, color: 'white', opacity: clamp01((t - 60) / 0.3)}}>
        {[['BRASIL INTEIRO', 201, '#9fd3e0', '≈ 201 MI'], ['NÍVEL 12', 244, '#ff8a6a', '244 MI']].map(([a, v, c, l], i) => (
          <div key={a} style={{display: 'flex', alignItems: 'center', gap: 20, marginBottom: 14}}>
            <div style={{width: 260, fontWeight: 800, fontSize: 28, letterSpacing: 2}}>{a}</div>
            <div style={{height: 46, width: 900 * v / 244 * clamp01((t - 60 - i * 0.3) / 0.7), background: c, borderRadius: 6}} />
            <div style={{fontWeight: 900, fontSize: 34}}>{l}</div>
          </div>
        ))}
      </div>}
    </>;
  }],
  [62.4, (t) => <>
    <SPiramide t={t} n={8} quebra={rampa(t, 65.7, 66.9)} keys={[{t: 62.4, p: [14, 5, 22], l: [0, 2.5, 0]}, {t: 66.6, p: [11, 4, 18], l: [0, 2, 0]}]} />
    <Num t={t} t0={65.8} txt="A CONTA ACABA" size={120} y={240} cor="#ff8a6a" />
  </>],
  [66.6, (t) => <>
    <SPiramide t={t} n={8} baseVermelha={rampa(t, 69.0, 69.8)} keys={[{t: 66.6, p: [3, 6.5, 9], l: [0, 3.5, 0]}, {t: 69.8, p: [9, 1.3, 9.5], l: [0, 0.8, 0]}, {t: 71.1, p: [9.5, 1.1, 9], l: [0, 0.8, 0]}]} />
    <Tag t={t} t0={69.8} x={110} y={180} txt="OS ÚLTIMOS A ENTRAR" cor={VERM} />
  </>],
  [71.1, (t) => <>
    <SMartelo t={t} bate={74.7} keys={[{t: 71.1, p: [6, 2.5, 10], l: [0, 1.5, 0]}, {t: 74.5, p: [4, 2.2, 7.5], l: [0, 1.6, 0]}]} />
    <Tag t={t} t0={71.2} x={110} y={180} txt="2013" size={56} />
  </>],
];

// ===================== 4. A JUÍZA =====================
const CIDADES = [[-67.8, -9.97], [-40.3, -20.3], [-46.6, -23.5], [-38.5, -12.97], [-60.0, -3.1], [-43.9, -19.9], [-38.5, -3.7], [-63.9, -8.76], [-49.3, -16.7], [-48.5, -1.45]];
const S4 = [
  [0, (t) => <>
    <SCidade t={t} keys={[{t: 0, p: [0, 3.5, 17], l: [0, 2, 0]}, {t: 2.7, p: [1, 2.6, 9], l: [0.8, 2, 0]}]} />
    <Tag t={t} t0={0.3} x={110} y={180} txt="MINISTÉRIO PÚBLICO DO ACRE" />
  </>],
  [2.7, (t) => <>
    <SDoc t={t} t0={2.75} t1={7.7} titulo="AÇÃO CIVIL PÚBLICA" sub="MP-AC · RESUMO" linhas={4}>
      <div style={{fontSize: 38, lineHeight: 1.45}}>O dinheiro pago aos divulgadores vinha <Marca p={rampa(t, 4.1, 7.0)}>de quem entrava, e não da venda do telefone.</Marca></div>
    </SDoc>
  </>],
  [7.7, (t) => <>
    <SMartelo t={t} bate={11.1} keys={[{t: 7.7, p: [6, 3.2, 10], l: [0, 1.6, -1]}, {t: 13.4, p: [3.5, 2.2, 7], l: [0, 1.4, 0]}]} />
    <Tag t={t} t0={8.1} x={110} y={180} txt="18 DE JUNHO DE 2013" sub="2ª VARA CÍVEL DE RIO BRANCO" />
    <Carimbo t={t} t0={11.15} txt="PAGAMENTOS SUSPENSOS" x={W / 2 + 200} y={760} rot={-6} size={60} fundo="rgba(0,0,0,0.35)" />
  </>],
  [13.4, (t) => <>
    <SGaiola t={t} t0={15.2} keys={[{t: 13.4, p: [0, 4.2, 9.5], l: [0, 1, 0]}, {t: 16.7, p: [1.5, 3.2, 7], l: [0, 1.2, 0]}]} />
    <Tag t={t} t0={15.4} x={110} y={180} txt="BENS BLOQUEADOS" cor={VERM} />
  </>],
  [16.7, (t) => <>
    <SCidade t={t} gente={420} sangue={rampa(t, 19.2, 20.0)} keys={[{t: 16.7, p: [0, 2.6, 15.5], l: [0, 2, 0]}, {t: 20.5, p: [0, 2.3, 13], l: [0, 2, 0]}]} />
    <Num t={t} t0={18.2} t1={19.1} txt="ALÍVIO?" size={150} y={260} cor="white" />
  </>],
  [20.5, (t) => <>
    <SMapa t={t} pulsos={CIDADES.map(([lon, lat], i) => ({lon, lat, t0: 20.6 + i * 0.22}))} keys={[{t: 20.5, p: [0, 22, 13], l: [0, 0, 0.5]}, {t: 23.4, p: [0, 19.5, 10.5], l: [0, 0, 0.4]}]} />
    <Tag t={t} t0={20.9} x={110} y={180} txt="PROTESTOS EM VÁRIAS CIDADES" cor={VERM} />
  </>],
  [23.4, (t) => <>
    <SCidade t={t} gente={650} placas pula sangue={0.35} keys={[{t: 23.4, p: [3, 2.6, 13.5], l: [0, 1.6, 3]}, {t: 26.3, p: [-2.5, 2.4, 12.5], l: [0, 1.7, 2]}]} />
    <Tag t={t} t0={23.6} x={110} y={180} txt="“É MARKETING DE REDE, NÃO PIRÂMIDE”" sub="DIZIAM OS DIVULGADORES" />
  </>],
  [26.3, (t) => <>
    <SCelulares t={t} t0={26.5} passo={0.2} keys={[{t: 26.3, p: [0, 6.8, 4.6], l: [0, 0, 0]}, {t: 32.7, p: [-0.6, 4.2, 2.6], l: [0, 0, 0]}]} />
    <Tag t={t} t0={28.3} x={110} y={180} txt="AMEAÇAS DE MORTE À JUÍZA" cor={VERM} size={48} />
    <Tag t={t} t0={29.7} x={110} y={310} txt="INVESTIGADAS PELA POLÍCIA E PELO MP" size={32} />
  </>],
  [32.7, (t) => <>
    <SPiramide t={t} n={8} luzTopo={0.5} keys={[{t: 32.7, p: [2, 4, 9], l: [0, 3, 0]}, {t: 35.3, p: [3, 3.5, 7.5], l: [0, 3, 0]}]} />
    <Escuro o={0.35} />
    <Num t={t} t0={33.1} txt="POR QUÊ?" size={200} cor="white" />
  </>],
  [35.3, (t) => {
    const cam = camK(KF, t);
    const lbl = (p, t0, txt, cor) => { const s = projeta(p, cam.pos, cam.look, cam.fov); return <Tag t={t} t0={t0} x={s[0]} y={s[1] - 90} txt={txt} size={30} ancora="center" cor={cor} />; };
    return <>
      <SFamilia t={t} keys={KF} tPilha={37.8} tDivida={39.6} tFam={41.8} tSome={45.6} tVira={46.9} />
      {t < 41.6 && lbl([0, 1.6, 0], 38.3, 'ECONOMIAS')}
      {lbl([1.4, 0.9, 0.4], 40.1, 'EMPRÉSTIMO', VERM)}
      {lbl([-3, 1.0, 1.2], 42.0, 'MÃE')}
      {lbl([3, 1.0, 1.0], 42.6, 'IRMÃO')}
      {lbl([0.2, 1.0, -3], 43.2, 'MELHOR AMIGO')}
    </>;
  }],
  [49.7, (t) => <>
    <SRoda t={t} para={57.5} keys={[{t: 49.7, p: [0, 3.5, 16], l: [0, 3, 0]}, {t: 57, p: [4, 3.4, 13], l: [0, 3, 0]}, {t: 59.5, p: [3, 2.6, 10.5], l: [0, 2.4, 0]}]} />
    <Tag t={t} t0={54.2} t1={57.4} x={110} y={180} txt="SÓ É BOA ENQUANTO GIRA" />
    <Tag t={t} t0={58.4} x={110} y={180} txt="QUEM TENTA PARAR VIRA O VILÃO" cor={VERM} />
  </>],
  [59.5, (t) => <>
    <SGlobo t={t} rot={(t) => [lerp(-0.1, 0.45, rampa(t, 59.6, 62.4)), lerp(face(-52), face(-74), rampa(t, 59.6, 62.4))]} pontos={[{lon: -67.8, lat: -9.97, t0: 59.5}]}
      keys={[{t: 59.5, p: [0, 0, 7.5], l: [0, 0, 0]}, {t: 62.4, p: [0, 0, 10], l: [0, 0, 0]}]} />
  </>],
];
const KF = [{t: 35.3, p: [0, 2.2, 5], l: [0, 1.2, 0]}, {t: 38.5, p: [0, 3.2, 7.5], l: [0, 1, 0]}, {t: 41.5, p: [0, 5.5, 10], l: [0, 0.8, 0]}, {t: 49.7, p: [1.5, 6.5, 10.5], l: [0, 0.6, 0]}];

// ===================== 5. DO OUTRO LADO DO MUNDO =====================
const EUA_PTS = [[-71.06, 42.36], [-71.8, 42.26], [-74, 40.7], [-71.4, 41.8], [-80.2, 25.8], [-70.9, 42.5], [-74.2, 40.9], [-81.4, 28.5]];
const S5 = [
  [0, (t) => <>
    <SGlobo t={t} rot={(t) => [0.6, face(-76) + t * 0.02]} pontos={EUA_PTS.map(([lon, lat], i) => ({lon, lat, t0: 0.4 + i * 0.6, s: 0.35}))}
      keys={[{t: 0, p: [0, 0, 10], l: [0, 0, 0]}, {t: 6.7, p: [0, 0.6, 7.6], l: [0, 0.7, 0]}]} />
    <Tag t={t} t0={0.3} x={110} y={180} txt="ESTADOS UNIDOS" />
    <Tag t={t} t0={3.6} x={110} y={310} txt="IMIGRANTES BRASILEIROS" sub="E DOMINICANOS" size={36} />
  </>],
  [6.7, (t) => <>
    <SDoc t={t} t0={6.75} t1={16} titulo="ACUSAÇÃO" sub="SEC E ESTADO DE MASSACHUSETTS · ABRIL DE 2014" linhas={6}>
      <div style={{fontSize: 36}}>Telexfree: <b>esquema de pirâmide</b>.</div>
    </SDoc>
    <Carimbo t={t} t0={11.8} txt="PIRÂMIDE" x={W / 2 - 220} y={H / 2 + 200} rot={-10} size={80} />
    <Carimbo t={t} t0={14.7} txt="FALÊNCIA" x={W / 2 + 260} y={H / 2 - 40} rot={8} size={80} />
    <FonteTxt t={t} txt="SEC, comunicado 2014-79" />
  </>],
  [16.0, (t) => <>
    <SGlobo t={t} rot={(t) => [lerp(0.5, 0.05, rampa(t, 18.4, 23)), lerp(face(-72), face(-55), rampa(t, 18.4, 23))]} aviao={{a: [-71, 42], b: VIX, t0: 18.6, t1: 23.0}}
      arcos={[{a: [-71, 42], b: VIX, t0: 18.6, t1: 23.0, h: 0.3, cor: '#9fd3e0'}]} keys={[{t: 16, p: [0, 0, 9], l: [0, 0, 0]}, {t: 24, p: [0, 0, 8.2], l: [0, 0, 0]}]} />
    <Tag t={t} t0={17.5} x={110} y={180} txt="CARLOS WANZELER" sub="SÓCIO BRASILEIRO · VOLTA AO BRASIL" />
    <Tag t={t} t0={20.3} x={110} y={320} txt="SEGUNDO A JUSTIÇA DOS EUA:" sub="SAIU AO SABER DAS ACUSAÇÕES" size={34} />
  </>],
  [24.0, (t) => <>
    <SCela t={t} desce={31.5} keys={[{t: 24, p: [0, 2.2, 8], l: [0, 1.1, 0]}, {t: 33, p: [0.5, 1.7, 5.4], l: [0, 1.2, 0]}]} />
    <Tag t={t} t0={25.6} x={110} y={180} txt="JAMES MERRILL" sub="SÓCIO AMERICANO · FICOU NOS EUA" />
    <Carimbo t={t} t0={29.0} txt="CULPADO · 2016" x={W - 520} y={330} rot={-8} size={64} fundo="rgba(0,0,0,0.35)" />
    <Num t={t} t0={31.6} txt="6 ANOS" sub="DE PRISÃO · 2017" x={W - 520} y={700} size={120} />
  </>],
  [33.0, (t) => <>
    <SMultidao t={t} t0={33.2} t1={36.6} vermelho={0.35} keys={[{t: 33, p: [0, 3, 7], l: [0, 0.6, 0]}, {t: 39.9, p: [0, 36, 30], l: [0, 0, 0]}]} />
    <Num t={t} t0={36.6} txt="≈ 1 MILHÃO" sub="DE PESSOAS PERDERAM DINHEIRO" y={250} size={140} />
    <FonteTxt t={t} txt="Boston Globe, 2020" />
  </>],
  [39.9, (t) => <>
    <SPilhas t={t} pilhas={[{x: -2.6, h: 10 * rampa(t, 40.2, 41.4), r: 2.2}, {x: 3.4, h: 0.5 * rampa(t, 47.0, 47.6), r: 2.2}]}
      keys={[{t: 39.9, p: [-2, 3, 18], l: [-1, 3, 0]}, {t: 43.4, p: [0, 7, 24], l: [0, 5, 0]}, {t: 47.0, p: [6, 3, 12], l: [2.5, 1, 0]}, {t: 51.2, p: [7, 2.5, 10.5], l: [2.8, 0.8, 0]}]} />
    <Num t={t} t0={40.6} t1={46.6} txt="US$ 3 BILHÕES" sub="PASSARAM PELO ESQUEMA" y={240} size={130} />
    <Tag t={t} t0={43.6} t1={46.6} x={110} y={420} txt="2020: JUIZ DOS EUA APROVA DEVOLUÇÃO" size={34} />
    <Num t={t} t0={47.2} txt="US$ 150 MILHÕES" sub="DEVOLVIDOS" x={W / 2 + 120} y={240} size={110} />
    <Tag t={t} t0={49.8} x={110} y={420} txt="≈ 100 MIL VÍTIMAS" />
    <FonteTxt t={t} txt="Boston Globe, 2020" />
  </>],
  [51.2, (t) => <>
    <SPizza t={t} t0={53.4} frac={0.4} keys={[{t: 51.2, p: [0, 8, 8], l: [0, 0, 0]}, {t: 56, p: [0, 6.5, 6.5], l: [0, 0, 0]}]} />
    <Num t={t} t0={53.5} txt="≈ 40%" sub="NA PRIMEIRA RODADA" x={W - 420} y={300} size={130} />
  </>],
];

// ===================== 6. E NO BRASIL? =====================
const MARCOS = [{x: 0, t: 2.6, tipo: 'piramide'}, {x: 9, t: 11.7, tipo: 'forum'}, {x: 16, t: 16.6, tipo: 'grade'}, {x: 23, t: 22.8, tipo: 'martelo'}, {x: 30, t: 30.0, tipo: 'jornal'}];
const KL = [{t: 0, p: [-7, 3.2, 8.5], l: [-3, 1, 0]}, {t: 2.5, p: [1.8, 2.8, 6.2], l: [0, 1, 0]}, {t: 10.8, p: [2.8, 2.5, 5.6], l: [0.6, 1, 0]},
  {t: 11.9, p: [10.2, 2.8, 6.2], l: [9, 1, 0]}, {t: 15.6, p: [10.6, 2.5, 5.6], l: [9, 1, 0]}, {t: 16.8, p: [17.8, 2.6, 6.0], l: [16, 1, 0]},
  {t: 22.0, p: [18.2, 2.4, 5.4], l: [16.3, 1, 0]}, {t: 23.0, p: [24.8, 2.8, 6.2], l: [23, 1, 0]}, {t: 29.3, p: [25.2, 2.5, 5.6], l: [23.3, 1, 0]},
  {t: 30.2, p: [31.8, 2.8, 6.2], l: [30, 0.8, 0]}, {t: 33.8, p: [32.2, 3.2, 6.6], l: [30.2, 0.6, 0]}];
const Ano = ({t, t0, t1, txt}) => <Num t={t} t0={t0} t1={t1} txt={txt} x={W - 330} y={190} size={120} />;
const S6 = [
  [0, (t) => <>
    <SLinha t={t} keys={KL} marcos={MARCOS} fimLinha={{x: 32, t0: 0.3, t1: 30.5}} />
    <Tag t={t} t0={0.6} t1={2.4} x={110} y={180} txt="JUSTIÇA DO ACRE" />
    <Ano t={t} t0={2.7} t1={11.4} txt="2015" />
    {t < 11.4 && <Carimbo t={t} t0={4.2} txt="ERA PIRÂMIDE" x={W - 420} y={420} rot={-8} size={60} fundo="rgba(0,0,0,0.35)" />}
    <Tag t={t} t0={6.3} t1={11.4} x={110} y={180} txt="DEVOLVER O DINHEIRO" sub="DOS DIVULGADORES" />
    <Tag t={t} t0={8.7} t1={11.4} x={110} y={310} txt="R$ 3 MILHÕES" sub="DANO MORAL COLETIVO" />
    <Ano t={t} t0={11.8} t1={22.5} txt="2019" />
    <Tag t={t} t0={12.9} t1={16.4} x={110} y={180} txt="FALÊNCIA DECRETADA" sub="VITÓRIA (ES)" />
    <Tag t={t} t0={16.7} t1={22.5} x={110} y={180} txt="PRESOS PELA POLÍCIA FEDERAL" sub="CARLOS WANZELER E CARLOS COSTA" />
    <Tag t={t} t0={21.3} t1={22.5} x={110} y={320} txt="SOLTOS NO DIA SEGUINTE" cor={VERM} />
    <Ano t={t} t0={22.9} t1={29.8} txt="2020" />
    <Tag t={t} t0={24.6} t1={29.8} x={110} y={180} txt="12 ANOS E MEIO DE PRISÃO" sub="CONDENAÇÃO EM 1ª INSTÂNCIA · CABE RECURSO" />
    <Ano t={t} t0={30.1} t1={33.6} txt="2023" />
    <Tag t={t} t0={31.3} t1={33.6} x={110} y={180} txt="RECORRIAM EM LIBERDADE" sub="ÚLTIMA REPORTAGEM SOBRE O CASO" />
    <FonteTxt t={t} txt="TJAC; A Gazeta (ES), 2023" />
  </>],
  [33.6, (t) => <>
    <SPiramide t={t} n={8} quebra={1} gente={false} luzTopo={0.3} keys={[{t: 33.6, p: [3, 2.2, 13], l: [0, 1, 3]}, {t: 40.5, p: [5, 4.5, 19], l: [0, 1, 2]}]}>
      <Boneco p={[0, 0, 7]} c="#5b6770" s={2.2} r={Math.PI} />
    </SPiramide>
    <Tag t={t} t0={37.0} x={110} y={180} txt="A MAIORIA NUNCA RECEBEU DE VOLTA" cor={VERM} />
  </>],
];

// ===================== FECHO =====================
const KFE = [{t: 0, p: [-14, 3.2, 9], l: [-9.75, 1.5, 0]}, {t: 6.6, p: [6, 3.2, 10], l: [3.25, 1.5, 0]}, {t: 9.8, p: [0, 7, 24], l: [0, 1.8, 0]}];
const SINAIS = ['GANHA MAIS POR INDICAR DO QUE POR VENDER', 'RENDE ALTO, FIXO E SEM RISCO', 'TEM PRESSA PRA VOCÊ ENTRAR'];
const S7 = [
  [0, (t) => {
    const cam = camK(KFE, t);
    return <>
      <SFecho t={t} keys={KFE} acende={[3.3, 4.1, 5.3, 6.5]} une={8.3} />
      {['BOI', 'AVESTRUZ', 'TELEFONE', 'CRIPTO'].map((nm, i) => {
        const s = projeta([(i - 1.5) * 6.5, 4.6, 0], cam.pos, cam.look, cam.fov);
        return t < 8.3 && s[0] > 80 && s[0] < W - 80 ? <Tag key={nm} t={t} t0={[3.3, 4.1, 5.3, 6.5][i]} x={s[0]} y={Math.max(170, s[1])} txt={nm} size={34} ancora="center" /> : null;
      })}
      <Num t={t} t0={8.4} txt="A MESMA CONTA" size={130} y={230} cor="#ff8a6a" />
    </>;
  }],
  [10.0, (t) => <>
    <SPiramide t={t} n={8} vermelho={0.5} keys={[{t: 10, p: [14, 5, 20], l: [3, 2.5, 0]}, {t: 18.5, p: [11, 4, 17], l: [3, 2.5, 0]}]} />
    <Escuro o={0.3} />
    {!FMT.v && <div style={{position: 'absolute', left: 110, top: 150, fontFamily: FONT, fontWeight: 800, fontSize: 34, letterSpacing: 8, color: '#9fd3e0', opacity: clamp01((t - 10) / 0.4)}}>SINAIS DE PIRÂMIDE</div>}
    {SINAIS.map((s, i) => <Tag key={i} t={t} t0={[10.1, 13.6, 16.5][i]} x={110} y={290 + i * 140} txt={`${i + 1}. ${s}`} size={44} cor={VERM} />)}
  </>],
  [18.5, (t) => {
    const keys = [{t: 18.5, p: [3, 7, 10], l: [0, 4.5, 0]}, {t: 20.0, p: [8, 1.6, 10.5], l: [0, 0.6, 0]}, {t: 21.4, p: [8.5, 1.5, 10], l: [0, 0.6, 0]}];
    return <>
      <SPiramide t={t} n={8} baseVermelha={rampa(t, 19.6, 20.2)} keys={keys} />
      <Num t={t} t0={20.2} txt="VOCÊ ESTÁ AQUI" size={90} y={900} cor="#ff8a6a" />
    </>;
  }],
  [21.4, (t) => <>
    <SPiramide t={t} n={8} luzTopo={0.6} keys={[{t: 21.4, p: [16, 6, 26], l: [0, 2.5, 0]}, {t: 30, p: [13, 5, 22], l: [0, 2.5, 0]}]} />
    <Escuro o={0.45} />
    <Num t={t} t0={21.6} txt="E VOCÊ?" size={150} y={380} cor="white" />
    <Num t={t} t0={22.3} txt="CONHECEU ALGUÉM QUE ENTROU?" size={64} y={560} cor={YELLOW} />
    <Num t={t} t0={24.2} txt="CONTA NOS COMENTÁRIOS" size={44} y={700} cor="#9fd3e0" />
  </>],
];

export const SHOTS = [S0, S1, S2, S3, S4, S5, S6, S7];
export const Bloco = ({i, t}) => {
  const L = SHOTS[i];
  let k = 0;
  for (let j = 0; j < L.length; j++) if (t >= L[j][0]) k = j;
  return <React.Fragment key={`${i}-${k}`}>{L[k][1](t)}</React.Fragment>;
};

export const Piloto = ({gpu = true}) => {
  setFmt({w: 1920, h: 1080, v: false, gpu});
  const frame = useCurrentFrame();
  const T = frame / FPS;
  let cena = null;
  for (let i = 0; i < 8; i++) {
    const b = BLOCOS[i];
    const prox = i < 7 ? (BLOCOS[i + 1].card ?? BLOCOS[i + 1].ini) : TOTAL + 1;
    const fimB = i === 0 ? b.titulo : prox;
    if (b.card != null && T >= b.card && T < b.ini) cena = <Cartao key={`c${i}`} n={i} titulo={CAPS[i]} lt={T - b.card} dur={CARD} />;
    else if (T >= b.ini && T < fimB) cena = <AbsoluteFill key={`b${i}`}><Bloco i={i} t={T - b.ini} /></AbsoluteFill>;
    else if (i === 0 && T >= b.titulo && T < b.titulo + TITULO) cena = <AbsoluteFill key="tit"><TituloCena lt={T - b.titulo} /></AbsoluteFill>;
  }
  const fade = interpolate(T, [0, 0.5, TOTAL - 1.6, TOTAL], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{background: 'black'}}>
      <AbsoluteFill style={{opacity: fade}}>{cena}</AbsoluteFill>
      <Vinheta forca={0.6} />
      <Faixas />
    </AbsoluteFill>
  );
};
