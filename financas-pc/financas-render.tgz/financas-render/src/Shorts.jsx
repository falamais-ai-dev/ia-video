// Shorts verticais (1080x1920) tirados do piloto: mesmas cenas 3D reenquadradas, com legenda.
import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate, spring} from 'remotion';
import {FPS, FONT, YELLOW, clamp01, Vinheta, setFmt} from './comum';
import {Bloco} from './Piloto';
import SH from './shorts.json';

const WV = 1080, HV = 1920;

// legenda: grupos de até 3 palavras, palavra falada em amarelo
const grupos = (ws) => {
  const g = []; let cur = [];
  ws.forEach((w, i) => {
    cur.push(w);
    const fim = /[.,:!?…]$/.test(w.w) || cur.length >= 3 || i === ws.length - 1 || (ws[i + 1] && ws[i + 1].s - w.e > 0.35);
    if (fim) { g.push(cur); cur = []; }
  });
  return g;
};
const Legenda = ({ws, t}) => {
  const G = grupos(ws);
  const k = G.findIndex((g, i) => t >= g[0].s - 0.05 && (i + 1 < G.length ? t < G[i + 1][0].s - 0.05 : t < g[g.length - 1].e + 0.5));
  if (k < 0) return null;
  const g = G[k];
  const p = spring({frame: Math.round((t - g[0].s + 0.05) * FPS), fps: FPS, config: {damping: 12, stiffness: 200, mass: 0.5}});
  return (
    <div style={{position: 'absolute', left: 60, right: 60, top: 1290, textAlign: 'center', transform: `scale(${0.85 + 0.15 * p})`, fontFamily: FONT, fontWeight: 900, fontSize: 92, lineHeight: 1.08,
      color: 'white', WebkitTextStroke: '14px black', paintOrder: 'stroke fill', textShadow: '0 8px 30px rgba(0,0,0,0.6)'}}>
      {g.map((w, i) => <span key={i} style={{color: t >= w.s - 0.03 ? (t < w.e + 0.08 ? YELLOW : 'white') : 'rgba(255,255,255,0.85)'}}>{w.w.toUpperCase()}{i < g.length - 1 ? ' ' : ''}</span>)}
    </div>
  );
};

export const Short = ({n = 1, gpu = true}) => {
  setFmt({w: WV, h: HV, v: true, gpu});
  const S = SH[n - 1];
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const seg = S.segs.filter((s) => t >= s.t0).pop() || S.segs[0];
  const lt = t - seg.t0;
  const fim = t > S.dur - 2.8;
  const fade = interpolate(t, [0, 0.25, S.dur - 0.5, S.dur], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const tp = spring({frame, fps: FPS, config: {damping: 14, stiffness: 140}});
  return (
    <AbsoluteFill style={{background: 'black'}}>
      <AbsoluteFill style={{opacity: fade}}>
        <AbsoluteFill key={`${seg.t0}`}><Bloco i={seg.bloco} t={seg.vt0 + Math.min(lt, seg.dur + 2.6)} /></AbsoluteFill>
      </AbsoluteFill>
      <Vinheta forca={0.55} />
      {/* barra de progresso */}
      <div style={{position: 'absolute', left: 0, top: 0, height: 10, width: WV * clamp01(t / S.dur), background: YELLOW}} />
      {/* título fixo no alto */}
      <div style={{position: 'absolute', left: 70, right: 70, top: 230, textAlign: 'center', transform: `translateY(${(1 - tp) * -60}px)`, opacity: tp}}>
        <div style={{display: 'inline-block', background: 'rgba(6,18,26,0.85)', borderBottom: `8px solid ${YELLOW}`, padding: '20px 34px', fontFamily: FONT, fontWeight: 900, fontSize: 62, lineHeight: 1.1, color: 'white', letterSpacing: 1}}>{S.titulo}</div>
      </div>
      {!fim && <Legenda ws={S.words} t={t} />}
      {fim && (
        <div style={{position: 'absolute', left: 0, right: 0, top: 1240, textAlign: 'center', fontFamily: FONT, opacity: clamp01((t - (S.dur - 2.8)) / 0.3)}}>
          <div style={{display: 'inline-block', background: YELLOW, color: 'black', fontWeight: 900, fontSize: 64, padding: '22px 40px', borderRadius: 18}}>▶ VÍDEO COMPLETO</div>
          <div style={{color: 'white', fontWeight: 800, fontSize: 40, marginTop: 22, letterSpacing: 3, textShadow: '0 2px 12px black'}}>NO LINK ABAIXO</div>
        </div>
      )}
    </AbsoluteFill>
  );
};
export const DUR_SHORTS = SH.map((s) => Math.round(s.dur * FPS));
