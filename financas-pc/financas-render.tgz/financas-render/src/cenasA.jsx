// Cenas reutilizáveis (parte A). Todos os tempos são do bloco de narração (t).
import React, {useMemo} from 'react';
import {AbsoluteFill} from 'remotion';
import * as THREE from 'three';
import {FPS, W, H, FONT, YELLOW, clamp01, rnd, lerp, ease, FMT} from './comum';
import {Palco, Chao, Cidade, Janelas, Forum, Multidao, Instancias, Piramide, Telefone, Pedestal, Celular, Casa, MapaBrasil, ll, pontosNoBrasil, sph, Aviao, OURO, OURO2, CORES, NOITE, Pilha} from './kit';
import {sp, rampa, camK, VERM, useTerra, Estrelas} from './base';

// ---------- cidade à noite com o fórum; multidão opcional ----------
export const SCidade = ({t, keys, janela = 1, gente = 0, placas = false, pula = false, sangue = 0, children}) => {
  const cam = camK(keys, t);
  const pessoas = useMemo(() => {
    const o = [];
    for (let i = 0; i < 700; i++) {
      const x = (rnd(i * 1.7) - 0.5) * 16, z = 2.4 + rnd(i * 3.1) * 7.5;
      o.push({x, z, c: CORES[i % CORES.length], ph: rnd(i * 5.3) * 6.28});
    }
    return o.sort((a, b) => a.z - b.z);
  }, []);
  const vis = pessoas.slice(0, Math.floor(gente));
  const items = vis.map((b) => ({p: [b.x, pula ? Math.max(0, Math.sin(t * 9 + b.ph)) * 0.12 : 0, b.z], c: b.c, s: 1.5}));
  return (
    <Palco cam={cam} fog={['#0d2f38', 16, 55]} amb={{cidade: false}}>
      <Chao />
      <Cidade raio={7.5} />
      <Janelas raio={7.5} />
      <Forum p={[0, 0, -1]} s={1.3} janela={janela} />
      <spotLight position={[0, 14, 8]} angle={0.5} penumbra={0.7} intensity={260} distance={40} color="#ffd890" />
      {sangue > 0 && <pointLight position={[0, 3, 5]} intensity={60 * sangue} distance={18} color="#ff3020" />}
      {items.length > 0 && <Multidao items={items} />}
      {placas && items.length > 0 && <>
        <Instancias items={items.map((b) => ({p: [b.p[0], b.p[1] + 1.05, b.p[2]]}))} geo={<boxGeometry args={[0.5, 0.32, 0.03]} />} cor="#e9e1c8" />
        <Instancias items={items.map((b) => ({p: [b.p[0], b.p[1] + 0.8, b.p[2]]}))} geo={<boxGeometry args={[0.03, 0.4, 0.03]} />} cor="#6d4c2f" />
      </>}
      {children}
    </Palco>
  );
};

// ---------- documento em papel sobre a mesa (HTML) ----------
export const SDoc = ({t, t0, t1, titulo, sub, linhas = 5, children, zoom = [1.0, 1.08], rot = -2}) => {
  const p = sp(t, t0, {damping: 16, stiffness: 110, mass: 0.8});
  const z = lerp(zoom[0], zoom[1], clamp01((t - t0) / Math.max(1, t1 - t0)));
  return (
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, #4a3a2a 0%, #2a1e15 45%, #0c0805 100%)', overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: FMT.w / 2, top: FMT.h / 2, width: 1000, transform: `translate(-50%,-50%) translateY(${(1 - p) * 900}px) rotate(${rot}deg) scale(${z * (FMT.v ? 0.92 : 1)})`,
        background: '#ddd2b6', color: '#2b2b2b', padding: '46px 60px', boxShadow: '0 30px 70px rgba(0,0,0,0.7)', fontFamily: 'Liberation Serif, serif'}}>
        <div style={{fontFamily: FONT, fontWeight: 900, fontSize: 40, letterSpacing: 2}}>{titulo}</div>
        {sub && <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 22, letterSpacing: 4, opacity: 0.6, marginTop: 6}}>{sub}</div>}
        <div style={{height: 3, background: '#2b2b2b', opacity: 0.6, margin: '16px 0 22px'}} />
        {children}
        {[...Array(linhas)].map((_, i) => (
          <div key={i} style={{height: 14, background: '#2b2b2b', opacity: 0.18, margin: '16px 0', width: `${70 + rnd(i * 3.3) * 30}%`}} />
        ))}
      </div>
    </AbsoluteFill>
  );
};

// ---------- celulares com balões vermelhos ----------
export const SCelulares = ({t, t0, passo = 0.17, keys, n = 15}) => {
  const cam = camK(keys, t);
  const fones = useMemo(() => [...Array(n)].map((_, i) => ({p: [(i % 5 - 2) * 1.25 + (rnd(i) - 0.5) * 0.3, 0.04, (Math.floor(i / 5) - 1) * 1.6 + (rnd(i * 2) - 0.5) * 0.3], r: (rnd(i * 7) - 0.5) * 0.5, ord: Math.floor(rnd(i * 11) * n)})), [n]);
  const lidos = fones.filter((_, i) => t > t0 + i * passo).length;
  return (
    <Palco cam={cam} fog={['#0b1014', 8, 30]} bg="#07090c" luz="interior" amb={{cidade: false, moedas: false}}>
      <Chao c="#1b1410" />
      <pointLight position={[0, 3, 1]} intensity={8 + 30 * clamp01(lidos / n)} distance={10} color="#ff3a2a" />
      {fones.map((f, i) => {
        const b = sp(t, t0 + i * passo);
        return (
          <group key={i} position={f.p} rotation={[-Math.PI / 2, 0, f.r]}>
            <Celular p={[0, 0, 0]} s={1.2} balao={b} />
          </group>
        );
      })}
    </Palco>
  );
};

// ---------- telefone dourado no pedestal ----------
export const STelefone = ({t, keys, ondas, apaga = 1e9, giro = 0.25, children}) => {
  const cam = camK(keys, t);
  const a = rampa(t, apaga, apaga + 1.4);
  const cor = new THREE.Color(OURO).lerp(new THREE.Color('#5a5f60'), a).getStyle();
  const poeira = useMemo(() => [...Array(160)].map((_, i) => [(rnd(i) - 0.5) * 6, rnd(i * 3) * 4, (rnd(i * 7) - 0.5) * 6]), []);
  return (
    <Palco cam={cam} fog={['#0b1d24', 10, 40]}>
      <Chao c="#10262d" />
      <Pedestal p={[0, 0, 0]} h={0.9} w={2.6} />
      <Telefone p={[0, 0.9, 0]} s={1} r={t * giro} cor={cor} emis={0.4 * (1 - a)} />
      <spotLight position={[0, 9, 3]} angle={0.35} penumbra={0.6} intensity={lerp(300, 70, a)} distance={30} color="#ffd890" />
      {ondas && [0, 1, 2, 3].map((k) => {
        const ph = ((t - ondas[0]) * 0.7 + k * 0.25) % 1;
        if (t < ondas[0] || t > ondas[1]) return null;
        return (
          <mesh key={k} position={[0, 1.6, 0]} rotation={[Math.PI / 2, 0, 0]} scale={0.6 + ph * 5}>
            <torusGeometry args={[1, 0.012, 6, 64]} />
            <meshBasicMaterial color="#7fe3ff" transparent opacity={(1 - ph) * 0.8} />
          </mesh>
        );
      })}
      {a > 0 && <Instancias items={poeira.map((p, i) => ({p: [p[0], (p[1] - t * 0.15 + 8) % 4, p[2]]}))} geo={<boxGeometry args={[0.02, 0.02, 0.02]} />} cor="#cfc6b0" emissive="#cfc6b0" ei={0.6 * a} />}
      {children}
    </Palco>
  );
};

// ---------- multidão que cresce em espiral ----------
export const SMultidao = ({t, keys, t0, t1, max = 5000, vermelho = 0, children}) => {
  const cam = camK(keys, t);
  const pts = useMemo(() => [...Array(max)].map((_, i) => {
    const r = 0.42 * Math.sqrt(i), a = i * 2.39996;
    return {p: [r * Math.cos(a) + (rnd(i) - 0.5) * 0.15, 0, r * Math.sin(a) + (rnd(i * 2) - 0.5) * 0.15], c: CORES[i % CORES.length]};
  }), [max]);
  const k = Math.floor(lerp(1, max, Math.pow(rampa(t, t0, t1), 2)));
  const items = pts.slice(0, k).map((b) => ({p: b.p, c: b.c, s: 1.4}));
  return (
    <Palco cam={cam} fog={['#0d2f38', 14, 70]} amb={{cidade: false}}>
      <Chao />
      <spotLight position={[0, 20, 0]} angle={0.7} penumbra={0.8} intensity={400} distance={60} color="#ffd890" />
      {vermelho > 0 && <pointLight position={[0, 6, 0]} intensity={200 * vermelho} distance={40} color="#ff2a1a" />}
      <Multidao items={items} />
      {children}
    </Palco>
  );
};

// ---------- pirâmide dourada (com fila de novatos e moedas subindo) ----------
export const SPiramide = ({t, keys, n, NIV = 8, HN = 0.72, w0 = 1.0, dw = 1.3, quebra = 0, congela = 0, gente = true, cidade = true, fila = false, moedas = false, baseVermelha = 0, vermelho = 0, luzTopo = 1, children}) => {
  const cam = camK(keys, t);
  const total = Math.min(n, NIV);
  const topoY = (total - 1) * HN + 1.2;
  const largBase = w0 + (Math.ceil(total) - 1) * dw;
  return (
    <Palco cam={cam} fog={['#0d2f38', 20, 70]} amb={{cidade: false}}>
      <Chao />
      {cidade && <Cidade raio={Math.max(7.5, largBase * 0.75 + 2)} />}
      <spotLight position={[0, 18, 7]} angle={0.42} penumbra={0.6} intensity={380 * (1 - congela * 0.4)} distance={55} color={congela ? '#a8d8ff' : '#ffd890'} />
      <pointLight position={[0, topoY, 0]} intensity={30 * luzTopo} distance={10} color="#ffbf40" />
      {vermelho > 0 && <pointLight position={[0, 2, largBase]} intensity={160 * vermelho} distance={25} color="#ff2a1a" />}
      <Piramide n={n} NIV={NIV} HN={HN} w0={w0} dw={dw} gente={gente} quebra={quebra} congela={congela} cor={congela ? new THREE.Color(OURO).lerp(new THREE.Color('#7fb8d8'), congela).getStyle() : OURO} />
      {baseVermelha > 0 && (
        <mesh position={[0, HN / 2, 0]}>
          <boxGeometry args={[largBase + 0.05, HN * 0.98, largBase + 0.05]} />
          <meshStandardMaterial color="#c62828" emissive="#ff1a1a" emissiveIntensity={0.8 * baseVermelha} transparent opacity={0.75 * baseVermelha} />
        </mesh>
      )}
      {fila && <Fila t={t} x0={largBase / 2 + 0.6} />}
      {moedas && <MoedasSobem t={t} base={largBase} topo={topoY - 0.6} />}
      {children}
    </Palco>
  );
};
const Fila = ({t, x0}) => {
  const it = [...Array(26)].map((_, i) => {
    const u = ((t * 0.55 + i * 0.65) % 17);
    return {p: [x0 + 16 - u, 0, 1.6 + Math.sin(i) * 0.2], c: CORES[i % CORES.length], s: 1.5};
  });
  return <Multidao items={it} />;
};
const MoedasSobem = ({t, base, topo}) => {
  const it = [...Array(30)].map((_, i) => {
    const u = ((t * 0.35 + i / 30) % 1);
    const s = base / 2 * (1 - u) + 0.3;
    const a = i * 2.4;
    return {p: [Math.cos(a) * s + 0.0, 0.3 + u * topo, Math.sin(a) * s + 0.3], r: [Math.PI / 2, 0, a]};
  });
  return <Instancias items={it} geo={<cylinderGeometry args={[0.16, 0.16, 0.05, 16]} />} cor="#ffc93c" emissive="#ffb300" ei={0.8} metalness={0.4} roughness={0.4} />;
};

// ---------- globo com arcos, pontos e avião ----------
const arcoPts = (a, b, r, h, p0, p1) => {
  const va = new THREE.Vector3(...sph(a[0], a[1], 1)), vb = new THREE.Vector3(...sph(b[0], b[1], 1));
  const pts = [];
  const N = 48;
  for (let i = 0; i <= N; i++) {
    const u = lerp(p0, p1, i / N);
    const v = va.clone().lerp(vb, u).normalize().multiplyScalar(r * (1 + h * Math.sin(Math.PI * u)));
    pts.push(v);
  }
  return pts;
};
export const SGlobo = ({t, keys, rot, arcos = [], pontos = [], aviao, r = 3, children}) => {
  const cam = camK(keys, t);
  const tex = useTerra();
  const [tilt, ry] = rot(t);
  return (
    <Palco cam={cam} fog={null} bg="#030a0f" amb={{cidade: false, part: false, moedas: false}}>
      <Estrelas />
      <ambientLight intensity={0.5} />
      <directionalLight position={[-4, 3, 8]} intensity={1.6} color="#ffffff" />
      <group rotation={[tilt, ry, 0]}>
        <mesh>
          <sphereGeometry args={[r, 96, 64]} />
          <meshStandardMaterial map={tex} roughness={0.85} emissive="#0c2a33" emissiveIntensity={0.25} />
        </mesh>
        <mesh scale={1.04}><sphereGeometry args={[r, 48, 32]} /><meshBasicMaterial color="#4fc3f7" transparent opacity={0.07} side={THREE.BackSide} /></mesh>
        {arcos.map((A, k) => {
          const p = rampa(t, A.t0, A.t1);
          if (p <= 0.01) return null;
          const pts = arcoPts(A.a, A.b, r, A.h || 0.25, 0, p);
          return (
            <mesh key={k}>
              <tubeGeometry args={[new THREE.CatmullRomCurve3(pts), 48, 0.012 * r, 6, false]} />
              <meshBasicMaterial color={A.cor || YELLOW} />
            </mesh>
          );
        })}
        {pontos.map((P, k) => {
          if (t < P.t0) return null;
          const s = sp(t, P.t0) * (P.s || 1);
          const pulso = 1 + 0.25 * Math.sin((t - P.t0) * 5 + k);
          return (
            <mesh key={k} position={sph(P.lon, P.lat, r * 1.005)} scale={s * pulso}>
              <sphereGeometry args={[0.06 * r, 12, 8]} />
              <meshBasicMaterial color={P.cor || VERM} />
            </mesh>
          );
        })}
        {aviao && t > aviao.t0 && t < aviao.t1 + 0.5 && (() => {
          const u = rampa(t, aviao.t0, aviao.t1);
          const pts = arcoPts(aviao.a, aviao.b, r, aviao.h || 0.3, Math.max(0, u - 0.02), Math.min(1, u + 0.02));
          const pos = pts[24], dir = pts[48].clone().sub(pts[0]).normalize();
          const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1, 0, 0), dir);
          return <group position={pos} quaternion={q}><Aviao p={[0, 0, 0]} s={0.22 * r} /></group>;
        })()}
      </group>
      {children}
    </Palco>
  );
};

// ---------- mapa do Brasil em relevo ----------
export const SMapa = ({t, keys, destaque = {}, pontos, pulsos = [], children}) => {
  const cam = camK(keys, t);
  const pts = useMemo(() => (pontos ? pontosNoBrasil(pontos.n, 3) : []), [pontos && pontos.n]);
  const vis = pontos ? pts.map((q, i) => ({q, i, d: Math.hypot(q.lon - pontos.de[0], q.lat - pontos.de[1])})).sort((a, b) => a.d - b.d) : [];
  const k = pontos ? Math.floor(vis.length * rampa(t, pontos.t0, pontos.t1)) : 0;
  return (
    <Palco cam={cam} fog={['#08202a', 18, 60]} bg="#051018" amb={{cidade: false, moedas: false}}>
      <Chao c="#0b2530" y={-0.01} />
      <spotLight position={[0, 22, 6]} angle={0.6} penumbra={0.7} intensity={500} distance={60} color="#ffe2b0" />
      <MapaBrasil destaque={destaque} />
      {k > 0 && <Instancias items={vis.slice(0, k).map(({q}) => ({p: ll(q.lon, q.lat, 0.32 + ((destaque[q.nm] || {}).sobe || 0) + (((destaque[q.nm] || {}).alt || 0.25) - 0.25))}))}
        geo={<sphereGeometry args={[0.07, 8, 6]} />} cor="#ffd54f" emissive="#ffb300" ei={1.4} />}
      {pulsos.map((P, i) => {
        if (t < P.t0) return null;
        const ph = ((t - P.t0) * 0.9) % 1;
        return (
          <group key={i} position={ll(P.lon, P.lat, 0.35)}>
            <mesh rotation={[-Math.PI / 2, 0, 0]} scale={0.2 + ph * 1.4}><torusGeometry args={[1, 0.05, 6, 40]} /><meshBasicMaterial color={P.cor || VERM} transparent opacity={1 - ph} /></mesh>
            <mesh><sphereGeometry args={[0.12, 10, 8]} /><meshBasicMaterial color={P.cor || VERM} /></mesh>
          </group>
        );
      })}
      {children}
    </Palco>
  );
};

// ---------- rua com 20 casas; uma acende ----------
export const SRua = ({t, keys, acende, idx = 12, children}) => {
  const cam = camK(keys, t);
  const l = rampa(t, acende, acende + 0.25);
  return (
    <Palco cam={cam} fog={['#0b2530', 10, 40]} amb={{cidade: false, moedas: false}}>
      <Chao c="#14343c" />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[13.5, 0.005, 1.6]}><planeGeometry args={[40, 1.6]} /><meshStandardMaterial color="#26383d" /></mesh>
      {[...Array(20)].map((_, i) => <Casa key={i} p={[i * 1.5, 0, 0]} luz={i === idx ? l : 0} c={['#d8e3e3', '#c9d8d0', '#dcd3c3'][i % 3]} />)}
      {[...Array(7)].map((_, i) => (
        <group key={i} position={[i * 4.5 + 0.7, 0, 2.6]}>
          <mesh position={[0, 0.9, 0]}><cylinderGeometry args={[0.03, 0.03, 1.8, 6]} /><meshStandardMaterial color="#333" /></mesh>
          <mesh position={[0, 1.82, 0]}><sphereGeometry args={[0.08, 8, 6]} /><meshStandardMaterial color="#ffe9b0" emissive="#ffd27a" emissiveIntensity={1.2} /></mesh>
        </group>
      ))}
      {l > 0 && <pointLight position={[idx * 1.5, 1.2, 1.2]} intensity={14 * l} distance={5} color="#ffbf40" />}
      {children}
    </Palco>
  );
};

export {OURO, OURO2, NOITE, Pilha};
