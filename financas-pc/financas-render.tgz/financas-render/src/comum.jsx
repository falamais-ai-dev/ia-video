import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig, Easing} from 'remotion';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';

export const FPS = 30;
export const W = 1920, H = 1080;
// formato da composição atual (vertical nos Shorts) e qualidade (gpu = render no PC com placa de vídeo)
export const FMT = {w: 1920, h: 1080, v: false, gpu: false};
export const setFmt = (o) => Object.assign(FMT, o);
const fovV = (f) => (FMT.v ? 2 * Math.atan(Math.tan((f * Math.PI) / 360) * 1.8) * 180 / Math.PI : f);
export const YELLOW = '#ffd400';
export const FONT = 'Montserrat';
export const clamp01 = (x) => Math.max(0, Math.min(1, x));
export const ease = Easing.bezier(0.45, 0, 0.2, 1);
export const pop = (frame, delay = 0) => spring({frame: frame - delay, fps: FPS, config: {damping: 11, stiffness: 160, mass: 0.6}});
export const rnd = (k) => { const x = Math.sin(k * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
export const lerp = (a, b, p) => a + (b - a) * p;
// keys: [{t (s), v: [..]}] -> vetor interpolado com ease
export const track = (keys, t) => {
  if (t <= keys[0].t) return keys[0].v;
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    if (t <= b.t) { const p = ease((t - a.t) / (b.t - a.t)); return a.v.map((x, j) => lerp(x, b.v[j], p)); }
  }
  return keys[keys.length - 1].v;
};

// câmera controlada pelo quadro
export const Cam = ({pos, look, fov = 35}) => {
  const {camera} = useThree();
  camera.position.set(...pos);
  const fv = fovV(fov);
  if (camera.fov !== fv) { camera.fov = fv; camera.updateProjectionMatrix(); }
  camera.lookAt(...look);
  return null;
};
// projeta um ponto 3D na tela (para rótulos em HTML presos ao 3D)
const _cam = new THREE.PerspectiveCamera(35, W / H, 0.1, 500);
export const projeta = (p, pos, look, fov = 35) => {
  _cam.fov = fov; _cam.aspect = W / H; _cam.updateProjectionMatrix();
  _cam.position.set(...pos); _cam.lookAt(...look); _cam.updateMatrixWorld();
  const v = new THREE.Vector3(...p).project(_cam);
  return [(v.x + 1) / 2 * W, (1 - v.y) / 2 * H];
};

// palavra -> grupos de até 5 palavras, quebrando na pontuação
export const grupos = (words, max = 5) => {
  const out = []; let cur = [];
  words.forEach((w, i) => {
    cur.push(w);
    if (cur.length >= max || /[.,:!?…]$/.test(w.w) || i === words.length - 1) { out.push(cur); cur = []; }
  });
  return out.map((g, i) => ({words: g, from: Math.round(g[0].s * FPS), to: i + 1 < out.length ? Math.round(out[i + 1][0].s * FPS) : Math.round((g[g.length - 1].e + 0.6) * FPS)}));
};
const limpa = (w) => w.replace(/[^\wÀ-ú%$]/g, '').toUpperCase();

// Legenda em caixa alta (Montserrat Black), palavra-chave em amarelo
export const Legenda = ({words, keys = [], y = 930, size = 70}) => {
  const frame = useCurrentFrame();
  const g = grupos(words).find((c) => frame >= c.from && frame < c.to);
  if (!g) return null;
  const p = pop(frame, g.from);
  const K = keys.map((k) => k.toUpperCase());
  return (
    <div style={{position: 'absolute', left: 120, width: W - 240, top: y - size, height: size * 2, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center',
      fontFamily: FONT, fontWeight: 900, fontSize: size, lineHeight: 1.05, textTransform: 'uppercase', color: 'white', WebkitTextStroke: '10px black', paintOrder: 'stroke fill',
      textShadow: '0 6px 16px rgba(0,0,0,0.6)', transform: `scale(${0.88 + 0.12 * p})`}}>
      <span>{g.words.map((w, i) => <span key={i} style={{color: K.includes(limpa(w.w)) ? YELLOW : 'white'}}>{w.w.replace(/\.\.\.$/, '…')} </span>)}</span>
    </div>
  );
};

// Legenda de documentário: frase em minúsculas, discreta, com fade
export const LegendaDoc = ({words, y = 960}) => {
  const frame = useCurrentFrame();
  const g = grupos(words, 7).find((c) => frame >= c.from && frame < c.to);
  if (!g) return null;
  const o = interpolate(frame, [g.from, g.from + 5, g.to - 4, g.to], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: 0, width: W, top: y - 40, textAlign: 'center', opacity: o,
      fontFamily: FONT, fontWeight: 600, fontSize: 46, color: 'white', textShadow: '0 2px 10px rgba(0,0,0,0.9), 0 0 2px black'}}>
      {g.words.map((w) => w.w).join(' ')}
    </div>
  );
};

// rótulo amarelo com linha até um ponto
export const Rotulo = ({x, y, tx, ty, text, delay = 0, size = 44, cor = YELLOW, corTexto = 'black'}) => {
  const frame = useCurrentFrame();
  if (frame < delay) return null;
  const p = pop(frame, delay);
  const l = clamp01((frame - delay) / 8);
  return (
    <>
      {tx !== undefined && (
        <svg style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}} width={W} height={H}>
          <line x1={x} y1={y} x2={lerp(x, tx, l)} y2={lerp(y, ty, l)} stroke="white" strokeWidth={6} strokeLinecap="round" />
          {l >= 1 && <circle cx={tx} cy={ty} r={11} fill="white" />}
        </svg>
      )}
      <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${p})`, background: cor, color: corTexto, borderRadius: 14,
        padding: `${size * 0.25}px ${size * 0.45}px`, fontFamily: FONT, fontWeight: 900, fontSize: size, whiteSpace: 'nowrap', boxShadow: '0 8px 20px rgba(0,0,0,0.35)'}}>{text}</div>
    </>
  );
};

// selo do estilo (canto superior esquerdo)
export const Selo = ({n, nome}) => (
  <div style={{position: 'absolute', left: 40, top: 36, background: 'rgba(0,0,0,0.6)', color: 'white', borderRadius: 12, padding: '10px 20px',
    fontFamily: FONT, fontWeight: 800, fontSize: 26, letterSpacing: 1}}>AMOSTRA {n} · {nome}</div>
);

export const Vinheta = ({forca = 0.55}) => (
  <AbsoluteFill style={{background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,${forca}) 100%)`, pointerEvents: 'none'}} />
);

// legenda manual: items [{s, e, t, k}] em segundos da voz (off = atraso da voz no vídeo)
export const Cap = ({items, off = 0, y = 945, size = 68}) => {
  const frame = useCurrentFrame();
  const tv = frame / FPS - off;
  const it = items.find((c) => tv >= c.s && tv < c.e);
  if (!it) return null;
  const p = pop(frame, Math.round((it.s + off) * FPS));
  const K = (it.k || '').toUpperCase().split('|');
  return (
    <div style={{position: 'absolute', left: 100, width: W - 200, top: y - size, height: size * 2, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center',
      fontFamily: FONT, fontWeight: 900, fontSize: size, textTransform: 'uppercase', color: 'white', WebkitTextStroke: '10px black', paintOrder: 'stroke fill',
      textShadow: '0 6px 16px rgba(0,0,0,0.6)', transform: `scale(${0.88 + 0.12 * p})`, whiteSpace: 'nowrap'}}>
      <span>{it.t.split(' ').map((w, i) => <span key={i} style={{color: K.includes(limpa(w)) ? YELLOW : 'white'}}>{w} </span>)}</span>
    </div>
  );
};
