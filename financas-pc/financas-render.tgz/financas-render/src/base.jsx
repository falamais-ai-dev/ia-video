// Utilidades do piloto: câmera por chaves, rótulos de documentário, carimbos.
import React, {useMemo, useState, useEffect} from 'react';
import {spring, staticFile, delayRender, continueRender} from 'remotion';
import * as THREE from 'three';
import {FPS, W, H, FONT, YELLOW, clamp01, lerp, ease, FMT} from './comum';

export const VERM = '#e53935';
export const sp = (t, t0, cfg) => (t < t0 ? 0 : spring({frame: (t - t0) * FPS, fps: FPS, config: cfg || {damping: 12, stiffness: 150, mass: 0.6}}));
export const rampa = (t, a, b) => ease(clamp01((t - a) / (b - a)));
export const lv = (A, B, p) => A.map((x, i) => lerp(x, B[i], p));

// chaves de câmera: [{t, p:[x,y,z], l:[x,y,z], f}]
export const camK = (keys, t) => {
  if (t <= keys[0].t) return {pos: keys[0].p, look: keys[0].l, fov: keys[0].f || 35};
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    if (t <= b.t) { const p = ease((t - a.t) / (b.t - a.t)); return {pos: lv(a.p, b.p, p), look: lv(a.l, b.l, p), fov: lerp(a.f || 35, b.f || 35, p)}; }
  }
  const z = keys[keys.length - 1];
  return {pos: z.p, look: z.l, fov: z.f || 35};
};

// rótulo de documentário: caixa escura com filete amarelo
export const Tag = ({t, t0, t1 = 1e9, x, y, txt, sub, cor = YELLOW, size = 40, ancora = 'left'}) => {
  if (FMT.v || t < t0 || t > t1 + 0.3) return null;
  const p = sp(t, t0);
  const o = clamp01((t1 + 0.3 - t) / 0.3) * clamp01(p * 2);
  const tx = ancora === 'center' ? '-50%' : ancora === 'right' ? '-100%' : '0';
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(${tx},-50%) translateX(${(1 - p) * -30}px)`, opacity: o,
      background: 'rgba(6,18,26,0.82)', borderLeft: `8px solid ${cor}`, padding: '12px 26px 12px 22px', fontFamily: FONT, color: 'white', boxShadow: '0 10px 30px rgba(0,0,0,0.5)'}}>
      <div style={{fontWeight: 900, fontSize: size, letterSpacing: 2, lineHeight: 1.05, whiteSpace: 'nowrap'}}>{txt}</div>
      {sub && <div style={{fontWeight: 600, fontSize: size * 0.5, letterSpacing: 3, color: '#9fd3e0', marginTop: 6, whiteSpace: 'nowrap'}}>{sub}</div>}
    </div>
  );
};

// número grande no meio da tela
export const Num = ({t, t0, t1 = 1e9, txt, sub, x = W / 2, y = H / 2, size = 170, cor = YELLOW}) => {
  if (FMT.v || t < t0 || t > t1 + 0.3) return null;
  const p = sp(t, t0, {damping: 10, stiffness: 170, mass: 0.6});
  const o = clamp01((t1 + 0.3 - t) / 0.3) * clamp01(p * 2);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${0.7 + 0.3 * p})`, opacity: o, textAlign: 'center', fontFamily: FONT}}>
      <div style={{fontWeight: 900, fontSize: size, color: cor, lineHeight: 1, textShadow: '0 8px 40px rgba(0,0,0,0.8)', whiteSpace: 'nowrap'}}>{txt}</div>
      {sub && <div style={{fontWeight: 800, fontSize: Math.max(30, size * 0.22), color: 'white', letterSpacing: 5, marginTop: 12, textShadow: '0 2px 14px rgba(0,0,0,0.95)', whiteSpace: 'nowrap'}}>{sub}</div>}
    </div>
  );
};

export const Carimbo = ({t, t0, txt, x, y, rot = -10, size = 70, cor = VERM, fundo}) => {
  if (FMT.v || t < t0) return null;
  const p = clamp01((t - t0) / 0.16);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${lerp(2.4, 1, p)})`, opacity: p, background: fundo,
      border: `9px solid ${cor}`, borderRadius: 14, padding: '6px 28px', color: cor, fontFamily: FONT, fontWeight: 900, fontSize: size, letterSpacing: 4, whiteSpace: 'nowrap'}}>{txt}</div>
  );
};

export const FonteTxt = ({t, t0 = -1, txt}) => (FMT.v || t < t0 ? null : (
  <div style={{position: 'absolute', right: 48, bottom: 78, fontFamily: FONT, fontWeight: 600, fontSize: 22, color: 'rgba(255,255,255,0.72)', textShadow: '0 1px 6px rgba(0,0,0,0.9)'}}>Fonte: {txt}</div>
));

export const Simulacao = () => FMT.v ? null : (
  <div style={{position: 'absolute', left: 48, top: 84, fontFamily: FONT, fontWeight: 800, fontSize: 24, letterSpacing: 4, color: '#9fd3e0', border: '2px solid #9fd3e0', padding: '4px 14px', borderRadius: 6}}>SIMULAÇÃO</div>
);

// textura do globo (carrega uma vez)
let _terra = null;
export const useTerra = () => {
  const [h] = useState(() => (_terra ? null : delayRender('terra')));
  const [tex, setTex] = useState(_terra);
  useEffect(() => {
    if (_terra) return;
    new THREE.TextureLoader().load(staticFile('terra.jpg'), (tx) => { tx.colorSpace = THREE.SRGBColorSpace; tx.anisotropy = 4; _terra = tx; setTex(tx); continueRender(h); });
  }, []);
  return tex;
};

// estrelas
export const Estrelas = ({n = 900, r = 60}) => {
  const arr = useMemo(() => {
    const a = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const u = Math.sin(i * 12.9898) * 43758.5453, v = Math.sin(i * 78.233) * 12345.678;
      const th = (u - Math.floor(u)) * Math.PI * 2, ph = Math.acos(2 * (v - Math.floor(v)) - 1);
      a[i * 3] = r * Math.sin(ph) * Math.cos(th); a[i * 3 + 1] = r * Math.cos(ph); a[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
    }
    return a;
  }, [n, r]);
  return (
    <points>
      <bufferGeometry><bufferAttribute attach="attributes-position" args={[arr, 3]} /></bufferGeometry>
      <pointsMaterial size={0.25} color="#cfe8ee" sizeAttenuation />
    </points>
  );
};
