import React from 'react';
import {Composition} from 'remotion';
import {Piloto} from './Piloto';
import {Short, DUR_SHORTS} from './Shorts';
import {TOTAL_F} from './tempo.mjs';
// gpu: true = qualidade cheia (render no PC); passar --props='{"gpu":false}' para a nuvem
export const Root = () => (
  <>
    <Composition id="Piloto" component={Piloto} durationInFrames={TOTAL_F} fps={30} width={1920} height={1080} defaultProps={{gpu: true}} />
    {DUR_SHORTS.map((d, i) => <Composition key={i} id={`Short${i + 1}`} component={Short} durationInFrames={d} fps={30} width={1080} height={1920} defaultProps={{n: i + 1, gpu: true}} />)}
  </>
);
