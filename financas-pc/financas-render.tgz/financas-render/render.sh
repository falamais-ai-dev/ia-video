#!/bin/sh
# Render do piloto e dos 4 Shorts na GPU. Uso: sh render.sh
cd "$(dirname "$0")"
[ -d node_modules ] || npm install
npx remotion bundle src/index.js --out-dir=build || exit 1
mkdir -p out
for c in Short1 Short2 Short3 Short4 Piloto; do
  s=$(date +%s)
  npx remotion render build $c out/$c-mudo.mp4 --muted --concurrency=6 --log=error && echo "$c ok $(( $(date +%s)-s ))s" | tee -a out/tempos.txt || echo "$c FALHOU" | tee -a out/tempos.txt
done
