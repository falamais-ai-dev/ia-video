import {Config} from '@remotion/cli/config';
// PC com GPU (Radeon): 'angle'. Se falhar, trocar para 'swangle' (CPU).
Config.setChromiumOpenGlRenderer('angle');
